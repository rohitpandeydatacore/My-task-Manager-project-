'use client';

import { useState } from 'react';
import { teamMembers } from './data/users';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import '../app/globals.css';

export default function RootLayout({ children }) {
  const [currentUser, setCurrentUser] = useState(teamMembers[0]); // Default: Admin Brijesh

  return (
    <html lang="en">
      <body>
        <div style={{ display: 'flex', minHeight: '100vh' }}>
          <Sidebar />
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
            <Header
              teamMembers={teamMembers}
              currentUser={currentUser}
              onUserChange={setCurrentUser}
            />
            <main style={{ padding: '24px', flex: 1, backgroundColor: '#f8fafc' }}>
              {/* Pass active user context/props to page components */}
              {children}
            </main>
          </div>
        </div>
      </body>
    </html>
  );
}
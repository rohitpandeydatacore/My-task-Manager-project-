'use client';

import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { initialTasks } from '../data/tasks';
import { teamMembers as defaultMembers } from '../data/users';
import { 
  getStoredTasks, 
  saveStoredTasks, 
  getStoredUsers, 
  getStoredTrash, 
  saveStoredTrash 
} from '../utils/storage';
import TaskForm from '../components/TaskForm';
import styles from './tasks.module.css';

export default function MyTasksPage() {
  const [tasks, setTasks] = useState(initialTasks);
  const [trash, setTrash] = useState([]);
  const [teamMembers, setTeamMembers] = useState(defaultMembers);
  const [currentUser, setCurrentUser] = useState(defaultMembers[0]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Filters and Search States
  const [statusFilter, setStatusFilter] = useState('all'); // 'all' | 'pending' | 'completed'
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState('latest');

  // Modal Control States
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [inspectTask, setInspectTask] = useState(null);
  const [isTrashOpen, setIsTrashOpen] = useState(false);

  // Helper function to truncate description to 4-5 words
  const getShortDescription = (text, wordLimit = 5) => {
    if (!text) return 'Personal learning and work tasks';
    const words = text.trim().split(/\s+/);
    if (words.length <= wordLimit) return text;
    return words.slice(0, wordLimit).join(' ') + '...';
  };

  useEffect(() => {
    setTasks(getStoredTasks(initialTasks));
    setTrash(getStoredTrash());
    setTeamMembers(getStoredUsers(defaultMembers));

    const savedUser = localStorage.getItem('creatofly_active_user');
    if (savedUser) {
      try {
        setCurrentUser(JSON.parse(savedUser));
      } catch (e) {
        console.error('Error parsing active user', e);
      }
    }
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    function handleUserSwitch() {
      setTeamMembers(getStoredUsers(defaultMembers));
      const savedUser = localStorage.getItem('creatofly_active_user');
      if (savedUser) {
        try {
          setCurrentUser(JSON.parse(savedUser));
        } catch (e) {
          console.error('Error parsing user', e);
        }
      }
    }
    window.addEventListener('activeUserChanged', handleUserSwitch);
    return () => window.removeEventListener('activeUserChanged', handleUserSwitch);
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveStoredTasks(tasks);
      saveStoredTrash(trash);
    }
  }, [tasks, trash, isLoaded]);

  // Handlers
  function handleToggleStatus(taskId) {
    const updated = tasks.map((t) => {
      if (t.id === taskId) {
        return { ...t, status: t.status === 'completed' ? 'pending' : 'completed' };
      }
      return t;
    });
    setTasks(updated);
  }

  // Moves task to trash bin
  function handleDeleteTask(taskId) {
    const taskToDelete = tasks.find((t) => t.id === taskId);
    if (!taskToDelete) return;

    const deletedItem = { ...taskToDelete, deletedAt: new Date().toISOString() };
    setTrash([deletedItem, ...trash]);
    setTasks(tasks.filter((t) => t.id !== taskId));
  }

  // Restores task from trash back to active list
  function handleRestoreTask(taskId) {
    const taskToRestore = trash.find((t) => t.id === taskId);
    if (!taskToRestore) return;

    const { deletedAt, ...restoredTask } = taskToRestore;
    setTasks([restoredTask, ...tasks]);
    setTrash(trash.filter((t) => t.id !== taskId));
  }

  // Permanently removes a task from trash
  function handlePermanentDelete(taskId) {
    if (confirm('Are you sure you want to permanently delete this task? This action cannot be undone.')) {
      setTrash(trash.filter((t) => t.id !== taskId));
    }
  }

  // Empties all personal trash tasks
  function handleEmptyTrash() {
    if (confirm('Are you sure you want to permanently delete all items in your trash?')) {
      const personalTaskIds = new Set(myTrash.map((t) => t.id));
      setTrash(trash.filter((t) => !personalTaskIds.has(t.id)));
    }
  }

  function handleSaveTask(formData) {
    if (editingTask) {
      setTasks(tasks.map((t) => (t.id === editingTask.id ? { ...t, ...formData } : t)));
    } else {
      const newTask = {
        id: Date.now(),
        ...formData,
        type: 'personal',               // Explicitly marked as personal
        ownerId: currentUser.id,          // Owned by user
        assignedTo: currentUser.id,       // Assigned to user themselves
        assignedBy: 'self',               // Flag to prevent leakage into team assigned task views
        status: 'pending',
        createdAt: new Date().toISOString().split('T')[0],
      };
      setTasks([newTask, ...tasks]);
    }
    setIsFormOpen(false);
  }

  // Strict filtering for personal active tasks and personal trash items
  const myTasks = tasks.filter(
    (t) =>
      t.type === 'personal' &&
      t.assignedBy === 'self' &&
      (t.ownerId === currentUser.id || t.assignedTo === currentUser.id)
  );

  const myTrash = trash.filter(
    (t) =>
      t.type === 'personal' &&
      t.assignedBy === 'self' &&
      (t.ownerId === currentUser.id || t.assignedTo === currentUser.id)
  );

  // Dynamic Category Calculation from actual user tasks
  const categoryCounts = myTasks.reduce((acc, task) => {
    const cat = task.category || 'Personal';
    acc[cat] = (acc[cat] || 0) + 1;
    return acc;
  }, {});

  // Stats calculation
  const totalCount = myTasks.length;
  const pendingCount = myTasks.filter((t) => t.status === 'pending').length;
  const completedCount = myTasks.filter((t) => t.status === 'completed').length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  // Filtering & Sorting for task display
  const filteredTasks = myTasks
    .filter((t) => {
      if (statusFilter === 'pending') return t.status === 'pending';
      if (statusFilter === 'completed') return t.status === 'completed';
      return true;
    })
    .filter((t) => t.title.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => {
      if (sortOrder === 'latest') return b.id - a.id;
      if (sortOrder === 'oldest') return a.id - b.id;
      return 0;
    });

  if (!isLoaded) return <div className={styles.container}>Loading My Tasks...</div>;

  return (
    <div className={styles.container}>
      {/* Top Header */}
      <div className={styles.topHeader}>
        <div>
          <h1 className={styles.pageTitle}>My Tasks</h1>
          <p className={styles.subTitle}>Manage your personal tasks. Add, edit, complete and stay productive.</p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button className={styles.trashBtn} onClick={() => setIsTrashOpen(true)}>
            🗑️ Trash ({myTrash.length})
          </button>
          <button
            className={styles.addBtn}
            onClick={() => {
              setEditingTask(null);
              setIsFormOpen(true);
            }}
          >
            + Add Task
          </button>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className={styles.mainLayout}>
        {/* Left Column: Controls & List */}
        <div className={styles.leftColumn}>
          {/* Controls Filter Bar */}
          <div className={styles.controlsBar}>
            <div className={styles.filterPills}>
              <button
                className={`${styles.pillBtn} ${statusFilter === 'all' ? styles.activePill : ''}`}
                onClick={() => setStatusFilter('all')}
              >
                All ({totalCount})
              </button>
              <button
                className={`${styles.pillBtn} ${statusFilter === 'pending' ? styles.activePill : ''}`}
                onClick={() => setStatusFilter('pending')}
              >
                Pending ({pendingCount})
              </button>
              <button
                className={`${styles.pillBtn} ${statusFilter === 'completed' ? styles.activePill : ''}`}
                onClick={() => setStatusFilter('completed')}
              >
                Completed ({completedCount})
              </button>
            </div>

            <div className={styles.searchAndSort}>
              <input
                type="text"
                placeholder="🔍 Search tasks..."
                className={styles.searchInput}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <select
                className={styles.sortSelect}
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value)}
              >
                <option value="latest">Sort by Latest</option>
                <option value="oldest">Sort by Oldest</option>
              </select>
            </div>
          </div>

          {/* Task List */}
          <div className={styles.taskList}>
            {filteredTasks.length > 0 ? (
              filteredTasks.map((task) => {
                const priorityClass =
                  task.priority === 'High'
                    ? styles.highPriority
                    : task.priority === 'Medium'
                    ? styles.mediumPriority
                    : styles.lowPriority;

                return (
                  <div key={task.id} className={styles.taskCardSlip}>
                    {/* Top Row inside Card Slip */}
                    <div className={styles.cardHeaderRow}>
                      <div className={styles.cardHeaderLeft}>
                        <input
                          type="checkbox"
                          className={styles.checkbox}
                          checked={task.status === 'completed'}
                          onChange={() => handleToggleStatus(task.id)}
                        />
                        <span className={`${styles.taskTitle} ${task.status === 'completed' ? styles.completedTitle : ''}`}>
                          {task.title}
                        </span>
                      </div>
                      <div className={styles.actionBtns}>
                        <button
                          className={styles.iconBtn}
                          title="View Task Details"
                          onClick={() => setInspectTask(task)}
                        >
                          👁️
                        </button>
                        <button
                          className={styles.iconBtn}
                          title="Edit Task"
                          onClick={() => {
                            setEditingTask(task);
                            setIsFormOpen(true);
                          }}
                        >
                          ✏️
                        </button>
                        <button
                          className={styles.iconBtn}
                          title="Delete Task"
                          onClick={() => handleDeleteTask(task.id)}
                        >
                          🗑️
                        </button>
                      </div>
                    </div>

                    {/* Description - Truncated to 4-5 Words */}
                    <p className={styles.taskDesc}>
                      {getShortDescription(task.description, 5)}
                    </p>

                    {/* Bottom Metadata Slip Row */}
                    <div className={styles.cardFooterRow}>
                      <div className={styles.badgeGroup}>
                        <span className={`${styles.badge} ${task.status === 'completed' ? styles.completedBadge : styles.pendingBadge}`}>
                          {task.status}
                        </span>
                        {task.priority && (
                          <span className={`${styles.badge} ${priorityClass}`}>
                            {task.priority} Priority
                          </span>
                        )}
                        <span className={styles.categoryBadge}>
                          {task.category || 'Personal'}
                        </span>
                      </div>

                      <div className={styles.timeText}>
                        📅 {task.dueDate || 'Today, 10:00 AM'}
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className={styles.emptyState}>
                No personal tasks found. Click "+ Add Task" to create your first personal task.
              </div>
            )}
          </div>
        </div>

        {/* Right Sidebar */}
        <div className={styles.rightColumn}>
          {/* Task Summary Donut */}
          <div className={styles.card}>
            <div className={styles.cardHeader}>
              <span className={styles.cardTitle}>Task Summary</span>
            </div>
            <div className={styles.donutContainer}>
              <div
                className={styles.donutRing}
                style={{
                  background: `conic-gradient(#10b981 ${progressPercent}%, #e2e8f0 0)`,
                }}
              >
                <div className={styles.donutInner}>
                  <span className={styles.percentageText}>{progressPercent}%</span>
                  <span className={styles.percentageLabel}>Completed</span>
                </div>
              </div>
              <div className={styles.legendList}>
                <div className={styles.legendItem}>
                  <span><span className={styles.dot} style={{ background: '#10b981' }}></span> Completed</span>
                  <b>{completedCount}</b>
                </div>
                <div className={styles.legendItem}>
                  <span><span className={styles.dot} style={{ background: '#f59e0b' }}></span> Pending</span>
                  <b>{pendingCount}</b>
                </div>
                <div className={styles.legendItem}>
                  <span>Total</span>
                  <b>{totalCount}</b>
                </div>
              </div>
            </div>
          </div>

          {/* Task Categories (Dynamically Generated) */}
          <div className={styles.card}>
            <div className={styles.cardHeader}>
              <span className={styles.cardTitle}>Task Categories</span>
            </div>
            <div className={styles.categoryList}>
              {Object.keys(categoryCounts).length > 0 ? (
                Object.entries(categoryCounts).map(([catName, count]) => (
                  <div key={catName} className={styles.categoryItem}>
                    <div className={styles.categoryLeft}>
                      <div className={styles.categoryIcon} style={{ background: '#f3e8ff', color: '#9333ea' }}>🏷️</div>
                      <span>{catName}</span>
                    </div>
                    <span className={styles.categoryCount}>{count}</span>
                  </div>
                ))
              ) : (
                <div className={styles.emptyState}>No active categories</div>
              )}
            </div>
          </div>

          {/* Quick Tips */}
          <div className={styles.tipCard}>
            <div className={styles.tipHeader}>
              <span>💡 Quick Tips</span>
            </div>
            <div className={styles.tipText}>
              "Break big tasks into smaller steps. Small progress every day leads to big results."
            </div>
          </div>

          {/* Focus Banner */}
          <div className={styles.focusBanner}>
            <div className={styles.focusTitle}>🎯 Stay Focused Keep Going!</div>
            <div className={styles.focusSub}>You're doing great. Keep tracking your progress.</div>
          </div>
        </div>
      </div>

      {/* Task Form Modal */}
      <TaskForm
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        onSubmit={handleSaveTask}
        initialTask={editingTask}
        isAssignedMode={false}
      />

      {/* Task Inspection View Portal Modal */}
      {inspectTask && isLoaded && createPortal(
        <InspectTaskModal
          inspectTask={inspectTask}
          onClose={() => setInspectTask(null)}
        />,
        document.body
      )}

      {/* Trash Bin Portal Modal */}
      {isTrashOpen && isLoaded && createPortal(
        <TrashBinModal
          trashList={myTrash}
          onClose={() => setIsTrashOpen(false)}
          onRestore={handleRestoreTask}
          onPermanentDelete={handlePermanentDelete}
          onEmptyTrash={handleEmptyTrash}
        />,
        document.body
      )}
    </div>
  );
}

// Modal Component for Task Inspection
function InspectTaskModal({ inspectTask, onClose }) {
  return (
    <div className={styles.darkModalOverlay} onClick={onClose}>
      <div className={styles.compactModalContent} onClick={(e) => e.stopPropagation()}>
        <div className={styles.modalHeader}>
          <h3 className={styles.compactModalTitle}>Task Details</h3>
          <button type="button" className={styles.closeBtnSmall} onClick={onClose}>✕</button>
        </div>

        <div className={styles.detailGroup}>
          <div className={styles.detailLabel}>TASK TITLE</div>
          <div className={styles.detailTitle}>{inspectTask.title}</div>
        </div>

        <div className={styles.detailGroup}>
          <div className={styles.detailLabel}>DESCRIPTION</div>
          <div 
            className={styles.detailText} 
            style={{ 
              maxHeight: '200px', 
              overflowY: 'auto', 
              whiteSpace: 'pre-wrap', 
              paddingRight: '6px' 
            }}
          >
            {inspectTask.description || 'No description provided.'}
          </div>
        </div>

        <div className={styles.detailGrid}>
          <div>
            <div className={styles.detailLabel}>DUE DATE</div>
            <div className={styles.detailVal}>{inspectTask.dueDate || 'Today, 10:00 AM'}</div>
          </div>
          <div>
            <div className={styles.detailLabel}>STATUS</div>
            <div className={styles.detailStatusVal}>{inspectTask.status}</div>
          </div>
          <div>
            <div className={styles.detailLabel}>PRIORITY</div>
            <div className={styles.detailVal}>{inspectTask.priority || 'Normal'}</div>
          </div>
          <div>
            <div className={styles.detailLabel}>CATEGORY</div>
            <div className={styles.detailVal}>{inspectTask.category || 'Personal'}</div>
          </div>
        </div>

        <button type="button" className={styles.primaryModalBtn} onClick={onClose}>
          Close
        </button>
      </div>
    </div>
  );
}

// Modal Component for Trash Bin Management
function TrashBinModal({ trashList, onClose, onRestore, onPermanentDelete, onEmptyTrash }) {
  return (
    <div className={styles.darkModalOverlay} onClick={onClose}>
      <div className={styles.trashModalContent} onClick={(e) => e.stopPropagation()}>
        <div className={styles.modalHeader}>
          <h3>🗑️ Trash Bin ({trashList.length})</h3>
          <button type="button" className={styles.closeBtnSmall} onClick={onClose}>✕</button>
        </div>

        <div className={styles.trashModalBody}>
          {trashList.length > 0 ? (
            trashList.map((task) => (
              <div key={task.id} className={styles.trashItemCard}>
                <div className={styles.trashItemInfo}>
                  <strong className={styles.trashItemTitle}>{task.title}</strong>
                  <p className={styles.trashItemSub}>{task.description || 'No description'}</p>
                </div>
                <div className={styles.trashItemActions}>
                  <button 
                    className={styles.restoreBtn} 
                    onClick={() => onRestore(task.id)}
                    title="Restore Task"
                  >
                    🔄 Restore
                  </button>
                  <button 
                    className={styles.permDeleteBtn} 
                    onClick={() => onPermanentDelete(task.id)}
                    title="Delete Permanently"
                  >
                    ❌ Delete
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className={styles.emptyTrashText}>Trash is empty.</div>
          )}
        </div>

        <div className={styles.modalFooterBetween}>
          {trashList.length > 0 && (
            <button type="button" className={styles.dangerBtn} onClick={onEmptyTrash}>
              Empty Trash
            </button>
          )}
          <button type="button" className={styles.secondaryBtn} onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
'use client';

import { useState, useEffect, useRef } from 'react';
import { initialTasks } from '../data/tasks';
import { teamMembers as defaultMembers } from '../data/users';
import {
  getStoredTasks,
  saveStoredTasks,
  getStoredUsers,
  getStoredTrash,
  saveStoredTrash
} from '../utils/storage';
import styles from './assigned.module.css';

export default function AssignedTasksPage() {
  const [tasks, setTasks] = useState(initialTasks);
  const [trash, setTrash] = useState([]);
  const [teamMembers, setTeamMembers] = useState(defaultMembers);
  const [currentUser, setCurrentUser] = useState(defaultMembers[0]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Filters & Controls
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState('latest');

  // Modal & Menu States
  const [selectedTask, setSelectedTask] = useState(null);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [isTrashOpen, setIsTrashOpen] = useState(false);
  const [editingTaskId, setEditingTaskId] = useState(null);
  const [activeMenuId, setActiveMenuId] = useState(null);

  // Task Form State
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    assignedTo: '',
    priority: 'Medium',
    dueDate: '',
    estimatedDuration: '',
    category: 'Development',
  });
  const [subtasksInput, setSubtasksInput] = useState([]);
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');

  const menuRef = useRef(null);

  useEffect(() => {
    setTasks(getStoredTasks(initialTasks));
    setTrash(getStoredTrash());
    setTeamMembers(getStoredUsers(defaultMembers));

    const savedUser = localStorage.getItem('creatofly_active_user');
    if (savedUser) {
      try {
        setCurrentUser(JSON.parse(savedUser));
      } catch (e) {
        console.error('Error parsing active user', e);
      }
    }
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    function handleUserSwitch() {
      setTeamMembers(getStoredUsers(defaultMembers));
      const savedUser = localStorage.getItem('creatofly_active_user');
      if (savedUser) {
        try {
          setCurrentUser(JSON.parse(savedUser));
        } catch (e) {
          console.error('Error parsing active user', e);
        }
      }
    }
    window.addEventListener('activeUserChanged', handleUserSwitch);
    return () => window.removeEventListener('activeUserChanged', handleUserSwitch);
  }, []);

  // Close three-dot menu when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setActiveMenuId(null);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveStoredTasks(tasks);
      saveStoredTrash(trash);
    }
  }, [tasks, trash, isLoaded]);

  const isAdmin = currentUser?.role?.toLowerCase() === 'admin';

  const assignedTasks = tasks.filter((t) => {
    if (t.type === 'personal' || t.assignedBy === 'self') {
      return false;
    }

    if (isAdmin) {
      return t.assignedBy === currentUser?.id || t.type === 'assigned';
    }
    return t.assignedTo === currentUser?.id || t.assignedBy === currentUser?.id;
  });

  const assignedTrash = trash.filter((t) => {
    if (t.type === 'personal' || t.assignedBy === 'self') {
      return false;
    }
    if (isAdmin) {
      return t.assignedBy === currentUser?.id || t.type === 'assigned';
    }
    return t.assignedTo === currentUser?.id || t.assignedBy === currentUser?.id;
  });

  function handleStatusUpdate(taskId, newStatus) {
    const updated = tasks.map((t) => (t.id === taskId ? { ...t, status: newStatus } : t));
    setTasks(updated);

    if (selectedTask && selectedTask.id === taskId) {
      setSelectedTask({ ...selectedTask, status: newStatus });
    }
    setActiveMenuId(null);
  }

  function handleToggleSubtask(taskId, subtaskId) {
    const updated = tasks.map((t) => {
      if (t.id === taskId && t.subtasks) {
        const updatedSubtasks = t.subtasks.map((st) =>
          st.id === subtaskId ? { ...st, completed: !st.completed } : st
        );
        return { ...t, subtasks: updatedSubtasks };
      }
      return t;
    });

    setTasks(updated);

    if (selectedTask && selectedTask.id === taskId) {
      const updatedSubtasks = selectedTask.subtasks.map((st) =>
        st.id === subtaskId ? { ...st, completed: !st.completed } : st
      );
      setSelectedTask({ ...selectedTask, subtasks: updatedSubtasks });
    }
  }

  // Soft Delete Handler (Moves to trash)
  function handleDeleteTask(taskId) {
    setActiveMenuId(null);
    if (window.confirm('Are you sure you want to move this task to trash?')) {
      const taskToDelete = tasks.find((t) => t.id === taskId);
      if (!taskToDelete) return;

      const deletedItem = { ...taskToDelete, deletedAt: new Date().toISOString() };
      setTrash([deletedItem, ...trash]);
      setTasks(tasks.filter((t) => t.id !== taskId));

      if (selectedTask?.id === taskId) {
        setSelectedTask(null);
      }
    }
  }

  // Restore Task from Trash
  function handleRestoreTask(taskId) {
    const taskToRestore = trash.find((t) => t.id === taskId);
    if (!taskToRestore) return;

    const { deletedAt, ...restoredTask } = taskToRestore;
    setTasks([restoredTask, ...tasks]);
    setTrash(trash.filter((t) => t.id !== taskId));
  }

  // Permanently Delete Task
  function handlePermanentDelete(taskId) {
    if (window.confirm('Are you sure you want to permanently delete this task? This cannot be undone.')) {
      setTrash(trash.filter((t) => t.id !== taskId));
    }
  }

  // Empty Entire Trash for Admin
  function handleEmptyTrash() {
    if (window.confirm('Are you sure you want to permanently delete all items in trash?')) {
      const assignedTrashIds = new Set(assignedTrash.map((t) => t.id));
      setTrash(trash.filter((t) => !assignedTrashIds.has(t.id)));
    }
  }

  function handleOpenCreateModal() {
    setEditingTaskId(null);
    setNewTask({
      title: '',
      description: '',
      assignedTo: '',
      priority: 'Medium',
      dueDate: '',
      estimatedDuration: '',
      category: 'Development',
    });
    setSubtasksInput([]);
    setNewSubtaskTitle('');
    setIsAssignModalOpen(true);
  }

  function handleOpenEditModal(task) {
    setActiveMenuId(null);
    setEditingTaskId(task.id);
    setNewTask({
      title: task.title || '',
      description: task.description || '',
      assignedTo: task.assignedTo || '',
      priority: task.priority || 'Medium',
      dueDate: task.dueDate || '',
      estimatedDuration: task.estimatedDuration || '',
      category: task.category || 'Development',
    });
    setSubtasksInput(task.subtasks ? [...task.subtasks] : []);
    setNewSubtaskTitle('');
    setIsAssignModalOpen(true);
  }

  function handleAddSubtask() {
    if (!newSubtaskTitle.trim()) return;
    setSubtasksInput([...subtasksInput, { id: Date.now(), title: newSubtaskTitle.trim(), completed: false }]);
    setNewSubtaskTitle('');
  }

  function handleRemoveSubtask(subtaskId) {
    setSubtasksInput(subtasksInput.filter((st) => st.id !== subtaskId));
  }

  function getShortPreviewText(text) {
    if (!text) return 'No description provided...';
    const words = text.trim().split(/\s+/);
    if (words.length <= 4) return text;
    return words.slice(0, 4).join(' ') + '...';
  }

  function handleSaveTask(e) {
    e.preventDefault();
    if (!newTask.title || !newTask.assignedTo) {
      alert('Please select a team member and enter a task title.');
      return;
    }

    if (editingTaskId) {
      // Update existing task
      const updated = tasks.map((t) => {
        if (t.id === editingTaskId) {
          return {
            ...t,
            title: newTask.title,
            description: newTask.description,
            priority: newTask.priority,
            assignedTo: Number(newTask.assignedTo) || newTask.assignedTo,
            dueDate: newTask.dueDate || t.dueDate || 'Jun 18, 2026',
            estimatedDuration: newTask.estimatedDuration || '',
            category: newTask.category,
            subtasks: subtasksInput,
          };
        }
        return t;
      });
      setTasks(updated);
    } else {
      // Create new task
      const createdTask = {
        id: Date.now(),
        title: newTask.title,
        description: newTask.description,
        priority: newTask.priority,
        status: 'assigned',
        type: 'assigned',
        assignedBy: currentUser?.id || 1,
        assignedTo: Number(newTask.assignedTo) || newTask.assignedTo,
        dueDate: newTask.dueDate || 'Jun 18, 2026',
        assignedDate: 'Jun 18, 2026',
        estimatedDuration: newTask.estimatedDuration || '',
        category: newTask.category,
        subtasks: subtasksInput,
      };
      setTasks([createdTask, ...tasks]);
    }

    setIsAssignModalOpen(false);
    setEditingTaskId(null);
    setNewTask({
      title: '',
      description: '',
      assignedTo: '',
      priority: 'Medium',
      dueDate: '',
      estimatedDuration: '',
      category: 'Development',
    });
    setSubtasksInput([]);
    setNewSubtaskTitle('');
  }

  const totalCount = assignedTasks.length;
  const assignedCount = assignedTasks.filter((t) => t.status === 'assigned' || t.status === 'pending').length;
  const inProgressCount = assignedTasks.filter((t) => t.status === 'in-progress').length;
  const completedCount = assignedTasks.filter((t) => t.status === 'completed').length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const filteredTasks = assignedTasks
    .filter((t) => {
      if (statusFilter === 'assigned') return t.status === 'assigned' || t.status === 'pending';
      if (statusFilter === 'in-progress') return t.status === 'in-progress';
      if (statusFilter === 'completed') return t.status === 'completed';
      return true;
    })
    .filter((t) => t.title.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => {
      if (sortOrder === 'latest') return b.id - a.id;
      if (sortOrder === 'oldest') return a.id - b.id;
      return 0;
    });

  const upcomingDeadlines = assignedTasks.filter((t) => t.status !== 'completed').slice(0, 3);

  if (!isLoaded) return <div className={styles.container}>Loading Assigned Tasks...</div>;

  return (
    <div className={styles.container}>
      {/* Top Header */}
      <div className={styles.topHeader}>
        <div>
          <h1 className={styles.pageTitle}>Assigned Tasks</h1>
          <p className={styles.subTitle}>
            {isAdmin
              ? 'Manage tasks you have assigned to team members and monitor their progress.'
              : 'Tasks assigned to you or created by you. Complete them and make progress!'}
          </p>
        </div>

        <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
          {/* Admin Controls: Trash Bin & Assign Task Button */}
          {isAdmin && (
            <>
              <button className={styles.cancelBtn} onClick={() => setIsTrashOpen(true)}>
                🗑️ Trash ({assignedTrash.length})
              </button>
              <button className={styles.assignTaskBtn} onClick={handleOpenCreateModal}>
                + Assign Task
              </button>
            </>
          )}
        </div>
      </div>

      {/* Main Layout */}
      <div className={styles.mainLayout}>
        <div className={styles.leftColumn}>
          {/* Controls Bar */}
          <div className={styles.controlsBar}>
            <div className={styles.filterPills}>
              <button
                className={`${styles.pillBtn} ${statusFilter === 'all' ? styles.activePill : ''}`}
                onClick={() => setStatusFilter('all')}
              >
                All ({totalCount})
              </button>
              <button
                className={`${styles.pillBtn} ${statusFilter === 'assigned' ? styles.activePill : ''}`}
                onClick={() => setStatusFilter('assigned')}
              >
                Assigned ({assignedCount})
              </button>
              <button
                className={`${styles.pillBtn} ${statusFilter === 'in-progress' ? styles.activePill : ''}`}
                onClick={() => setStatusFilter('in-progress')}
              >
                In Progress ({inProgressCount})
              </button>
              <button
                className={`${styles.pillBtn} ${statusFilter === 'completed' ? styles.activePill : ''}`}
                onClick={() => setStatusFilter('completed')}
              >
                Completed ({completedCount})
              </button>
            </div>

            <div className={styles.searchAndSort}>
              <input
                type="text"
                placeholder="🔍 Search assigned tasks..."
                className={styles.searchInput}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <select
                className={styles.sortSelect}
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value)}
              >
                <option value="latest">Sort by Latest</option>
                <option value="oldest">Sort by Oldest</option>
              </select>
            </div>
          </div>

          {/* Task List */}
          <div className={styles.taskList}>
            {filteredTasks.length > 0 ? (
              filteredTasks.map((task) => {
                const assigner = teamMembers.find((m) => m.id === task.assignedBy);
                const assignee = teamMembers.find((m) => m.id === task.assignedTo);
                const totalSubtasks = task.subtasks?.length || 0;
                const completedSubtasks = task.subtasks?.filter((s) => s.completed).length || 0;
                const isCompleted = task.status === 'completed';
                const isInProgress = task.status === 'in-progress';
                const isPendingOrAssigned = task.status === 'assigned' || task.status === 'pending';

                return (
                  <div key={task.id} className={styles.taskCard}>
                    <div className={styles.taskMain}>
                      <div className={styles.categoryBox} style={{ background: '#eff6ff', color: '#2563eb' }}>
                        &lt;/&gt;
                      </div>
                      <div className={styles.taskDetails}>
                        <span className={styles.taskTitle}>{task.title}</span>

                        <span className={styles.taskDesc}>
                          {getShortPreviewText(task.description)}
                        </span>

                        <div className={styles.taskMetaList}>
                          <span>👤 Assigned to: {assignee?.name || 'Unassigned'}</span>
                          <span>✍️ By: {assigner?.name || 'Brijesh Singh'}</span>
                          <span>📅 Assigned: {task.assignedDate || 'Jun 18, 2026'}</span>
                          {totalSubtasks > 0 && (
                            <span>📌 Subtasks: {completedSubtasks}/{totalSubtasks}</span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className={styles.taskRight}>
                      <div className={styles.statusBlock}>
                        <span
                          className={`${styles.badge} ${
                            isCompleted
                              ? styles.completedBadge
                              : isInProgress
                              ? styles.inProgressBadge
                              : styles.assignedBadge
                          }`}
                        >
                          {isInProgress ? 'In Progress' : task.status}
                        </span>
                        <span className={styles.dueDateText}>Due: {task.dueDate || 'Jun 18, 2026'}</span>
                      </div>

                      <div className={styles.buttonGroup}>
                        {/* Start and Complete buttons are hidden for Admins */}
                        {!isAdmin && (
                          <>
                            {isPendingOrAssigned && (
                              <button
                                className={styles.actionBtn}
                                onClick={() => handleStatusUpdate(task.id, 'in-progress')}
                              >
                                Start
                              </button>
                            )}

                            {isInProgress && (
                              <button
                                className={styles.actionBtn}
                                onClick={() => handleStatusUpdate(task.id, 'completed')}
                              >
                                Complete
                              </button>
                            )}

                            {isCompleted && (
                              <button
                                className={styles.redoBtn}
                                title="Re-open task"
                                onClick={() => handleStatusUpdate(task.id, 'in-progress')}
                              >
                                ↩ Redo
                              </button>
                            )}
                          </>
                        )}

                        {/* Three-dot Options Menu */}
                        <div className={styles.menuWrapper} ref={activeMenuId === task.id ? menuRef : null}>
                          <button
                            className={styles.dotsBtn}
                            title="Options"
                            onClick={() => setActiveMenuId(activeMenuId === task.id ? null : task.id)}
                          >
                            •••
                          </button>

                          {activeMenuId === task.id && (
                            <div className={styles.dropdownMenu}>
                              <button
                                className={styles.dropdownItem}
                                onClick={() => {
                                  setActiveMenuId(null);
                                  setSelectedTask(task);
                                }}
                              >
                                👁️ View Details
                              </button>
                              <button
                                className={styles.dropdownItem}
                                onClick={() => handleOpenEditModal(task)}
                              >
                                ✏️ Edit Task
                              </button>
                              {!isCompleted && !isAdmin && (
                                <button
                                  className={styles.dropdownItem}
                                  onClick={() => handleStatusUpdate(task.id, 'completed')}
                                >
                                  ✅ Mark as Completed
                                </button>
                              )}
                              {/* Delete button is rendered only for Admin */}
                              {isAdmin && (
                                <button
                                  className={`${styles.dropdownItem} ${styles.deleteDropdownItem}`}
                                  onClick={() => handleDeleteTask(task.id)}
                                >
                                  🗑️ Delete
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className={styles.emptyState}>No assigned tasks found matching your criteria.</div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className={styles.rightColumn}>
          <div className={styles.card}>
            <div className={styles.cardHeader}>
              <span className={styles.cardTitle}>Assigned Tasks Overview</span>
            </div>
            <div className={styles.donutContainer}>
              <div
                className={styles.donutRing}
                style={{ background: `conic-gradient(#10b981 ${progressPercent}%, #e2e8f0 0)` }}
              >
                <div className={styles.donutInner}>
                  <span className={styles.percentageText}>{progressPercent}%</span>
                  <span className={styles.percentageLabel}>Completed</span>
                </div>
              </div>
              <div className={styles.legendList}>
                <div className={styles.legendItem}>
                  <span><span className={styles.dot} style={{ background: '#10b981' }}></span> Completed</span>
                  <b>{completedCount}</b>
                </div>
                <div className={styles.legendItem}>
                  <span><span className={styles.dot} style={{ background: '#f59e0b' }}></span> In Progress</span>
                  <b>{inProgressCount}</b>
                </div>
                <div className={styles.legendItem}>
                  <span><span className={styles.dot} style={{ background: '#0284c7' }}></span> Assigned</span>
                  <b>{assignedCount}</b>
                </div>
                <div className={styles.legendItem}>
                  <span>Total</span>
                  <b>{totalCount}</b>
                </div>
              </div>
            </div>
          </div>

          <div className={styles.card}>
            <div className={styles.cardHeader}>
              <span className={styles.cardTitle}>Upcoming Deadlines</span>
              <span style={{ fontSize: '12px', color: '#2563eb', fontWeight: '600', cursor: 'pointer' }}>View All</span>
            </div>
            <div className={styles.deadlineList}>
              {upcomingDeadlines.length > 0 ? (
                upcomingDeadlines.map((item) => (
                  <div key={item.id} className={styles.deadlineItem}>
                    <div className={styles.deadlineLeft}>
                      <div className={styles.deadlineIcon}>📅</div>
                      <span className={styles.deadlineTitle}>{item.title}</span>
                    </div>
                    <div className={styles.deadlineRight}>
                      <div className={styles.dateVal}>{item.dueDate || 'Jun 18'}</div>
                      <div className={styles.daysLeft}>Upcoming</div>
                    </div>
                  </div>
                ))
              ) : (
                <div style={{ fontSize: '12px', color: '#94a3b8' }}>No upcoming deadlines</div>
              )}
            </div>
          </div>

          <div className={styles.tipCard}>
            <div className={styles.tipHeader}>
              <span>💡 Tips for Success</span>
            </div>
            <div className={styles.tipText}>
              "Focus on one task at a time. Consistency builds real skills."
            </div>
          </div>

          <div className={styles.focusBanner}>
            <div className={styles.focusTitle}>🚀 Progress Happens</div>
            <div className={styles.focusSub}>One task at a time. You've got this!</div>
          </div>
        </div>
      </div>

      {/* Admin Trash Bin Modal */}
      {isTrashOpen && isAdmin && (
        <div className={styles.modalOverlay} onClick={() => setIsTrashOpen(false)}>
          <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <span className={styles.modalTitle}>🗑️ Trash Bin ({assignedTrash.length})</span>
              <button className={styles.closeBtn} onClick={() => setIsTrashOpen(false)}>✕</button>
            </div>

            <div className={styles.modalBody}>
              {assignedTrash.length > 0 ? (
                assignedTrash.map((task) => (
                  <div
                    key={task.id}
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      padding: '12px',
                      background: '#f8fafc',
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px',
                      marginBottom: '10px'
                    }}
                  >
                    <div>
                      <strong style={{ fontSize: '14px', color: '#1e293b' }}>{task.title}</strong>
                      <p style={{ fontSize: '12px', color: '#64748b', margin: '2px 0 0 0' }}>
                        {task.description || 'No description'}
                      </p>
                    </div>
                    <div style={{ display: 'flex', gap: '8px' }}>
                      <button
                        className={styles.actionBtn}
                        onClick={() => handleRestoreTask(task.id)}
                      >
                        🔄 Restore
                      </button>
                      <button
                        className={styles.cancelBtn}
                        style={{ color: '#ef4444', borderColor: '#fca5a5' }}
                        onClick={() => handlePermanentDelete(task.id)}
                      >
                        ❌ Permanent Delete
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div style={{ textAlign: 'center', color: '#94a3b8', padding: '20px 0' }}>
                  Trash bin is empty.
                </div>
              )}
            </div>

            <div className={styles.modalFooter} style={{ justifyContent: 'space-between' }}>
              {assignedTrash.length > 0 && (
                <button
                  className={styles.cancelBtn}
                  style={{ background: '#ef4444', color: '#fff', border: 'none' }}
                  onClick={handleEmptyTrash}
                >
                  Empty Trash
                </button>
              )}
              <button className={styles.cancelBtn} onClick={() => setIsTrashOpen(false)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pop-up Box to Create/Edit Task (Admin Only) */}
      {isAssignModalOpen && isAdmin && (
        <div className={styles.modalOverlay} onClick={() => setIsAssignModalOpen(false)}>
          <div className={styles.popupCardModal} onClick={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <span className={styles.popupCardTitle}>
                {editingTaskId ? 'Edit Task' : 'Assign Task'}
              </span>
              <button className={styles.closeBtn} onClick={() => setIsAssignModalOpen(false)}>✕</button>
            </div>

            <form onSubmit={handleSaveTask} className={styles.modalBody}>
              <div className={styles.modalField}>
                <label className={styles.modalLabel}>Assign To (Team Member) *</label>
                <select
                  required
                  className={styles.formInput}
                  value={newTask.assignedTo}
                  onChange={(e) => setNewTask({ ...newTask, assignedTo: e.target.value })}
                >
                  <option value="">Select Team Member...</option>
                  {teamMembers.map((member) => (
                    <option key={member.id} value={member.id}>
                      👤 {member.name} ({member.role || 'member'})
                    </option>
                  ))}
                </select>
              </div>

              <div className={styles.modalField}>
                <label className={styles.modalLabel}>Task Title *</label>
                <input
                  type="text"
                  required
                  placeholder="Enter task title"
                  className={styles.formInput}
                  value={newTask.title}
                  onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                />
              </div>

              <div className={styles.modalField}>
                <label className={styles.modalLabel}>Description</label>
                <textarea
                  rows={3}
                  placeholder="Provide details or instructions for this task..."
                  className={styles.formInput}
                  value={newTask.description}
                  onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                />
              </div>

              <div className={styles.modalGrid}>
                <div className={styles.modalField}>
                  <label className={styles.modalLabel}>Priority</label>
                  <select
                    className={styles.formInput}
                    value={newTask.priority}
                    onChange={(e) => setNewTask({ ...newTask, priority: e.target.value })}
                  >
                    <option value="Low">⚡ Low</option>
                    <option value="Medium">⚡ Medium</option>
                    <option value="High">⚡ High</option>
                  </select>
                </div>

                <div className={styles.modalField}>
                  <label className={styles.modalLabel}>Due Date</label>
                  <input
                    type="date"
                    className={styles.formInput}
                    value={newTask.dueDate}
                    onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
                  />
                </div>
              </div>

              <div className={styles.modalField}>
                <label className={styles.modalLabel}>Estimated Duration</label>
                <input
                  type="text"
                  placeholder="e.g. 2 hours or 45 mins"
                  className={styles.formInput}
                  value={newTask.estimatedDuration}
                  onChange={(e) => setNewTask({ ...newTask, estimatedDuration: e.target.value })}
                />
              </div>

              <div className={styles.modalField}>
                <label className={styles.modalLabel}>Sub-tasks / Breakdowns</label>
                <div className={styles.subtaskInputRow}>
                  <input
                    type="text"
                    placeholder="Add step/sub-task"
                    className={styles.formInput}
                    value={newSubtaskTitle}
                    onChange={(e) => setNewSubtaskTitle(e.target.value)}
                  />
                  <button type="button" className={styles.blueAddBtn} onClick={handleAddSubtask}>
                    + Add
                  </button>
                </div>

                {subtasksInput.length > 0 && (
                  <div className={styles.subtaskList}>
                    {subtasksInput.map((st) => (
                      <div key={st.id} className={styles.subtaskItem}>
                        <span>• {st.title}</span>
                        <button
                          type="button"
                          className={styles.removeSubtaskBtn}
                          onClick={() => handleRemoveSubtask(st.id)}
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className={styles.popupFooterActions}>
                <button type="button" className={styles.cancelBtn} onClick={() => setIsAssignModalOpen(false)}>
                  Cancel
                </button>
                <button type="submit" className={styles.createTaskSubmitBtn}>
                  {editingTaskId ? 'Save Changes' : 'Assign Task'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Task Details Popup Modal */}
      {selectedTask && (
        <div className={styles.modalOverlay} onClick={() => setSelectedTask(null)}>
          <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <span className={styles.modalTitle}>Task Details</span>
              <button className={styles.closeBtn} onClick={() => setSelectedTask(null)}>✕</button>
            </div>

            <div className={styles.modalBody}>
              <div className={styles.modalField}>
                <span className={styles.modalLabel}>Task Title</span>
                <span className={styles.modalVal} style={{ fontWeight: '700', fontSize: '16px' }}>
                  {selectedTask.title}
                </span>
              </div>

              {/* Scrollable Description */}
              <div className={styles.modalField}>
                <span className={styles.modalLabel}>Full Description</span>
                <div className={styles.descriptionScrollArea}>
                  {selectedTask.description || 'No detailed description provided for this task.'}
                </div>
              </div>

              {selectedTask.subtasks && selectedTask.subtasks.length > 0 && (
                <div className={styles.modalField}>
                  <span className={styles.modalLabel}>Subtasks Checklist</span>
                  <div className={styles.subtaskChecklist}>
                    {selectedTask.subtasks.map((st) => (
                      <label key={st.id} className={styles.subtaskCheckboxLabel}>
                        <input
                          type="checkbox"
                          checked={st.completed}
                          onChange={() => handleToggleSubtask(selectedTask.id, st.id)}
                        />
                        <span style={{ textDecoration: st.completed ? 'line-through' : 'none' }}>
                          {st.title}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              <div className={styles.modalGrid}>
                <div className={styles.modalField}>
                  <span className={styles.modalLabel}>Assigned By</span>
                  <span className={styles.modalVal}>
                    {teamMembers.find((m) => m.id === selectedTask.assignedBy)?.name || 'Brijesh Singh'}
                  </span>
                </div>
                <div className={styles.modalField}>
                  <span className={styles.modalLabel}>Assigned To</span>
                  <span className={styles.modalVal}>
                    {teamMembers.find((m) => m.id === selectedTask.assignedTo)?.name || 'Member'}
                  </span>
                </div>
              </div>

              <div className={styles.modalGrid}>
                <div className={styles.modalField}>
                  <span className={styles.modalLabel}>Priority</span>
                  <span className={styles.modalVal}>{selectedTask.priority || 'Medium'}</span>
                </div>
                <div className={styles.modalField}>
                  <span className={styles.modalLabel}>Estimated Duration</span>
                  <span className={styles.modalVal}>{selectedTask.estimatedDuration || 'Not set'}</span>
                </div>
              </div>

              <div className={styles.modalGrid}>
                <div className={styles.modalField}>
                  <span className={styles.modalLabel}>Assigned Date</span>
                  <span className={styles.modalVal}>{selectedTask.assignedDate || 'Jun 18, 2026'}</span>
                </div>
                <div className={styles.modalField}>
                  <span className={styles.modalLabel}>Due Date</span>
                  <span className={styles.modalVal}>{selectedTask.dueDate || 'Jun 18, 2026'}</span>
                </div>
              </div>
            </div>

            <div className={styles.modalFooter}>
              <button className={styles.cancelBtn} onClick={() => setSelectedTask(null)}>
                Close
              </button>

              {!isAdmin && (selectedTask.status === 'assigned' || selectedTask.status === 'pending') && (
                <button
                  className={styles.actionBtn}
                  onClick={() => {
                    handleStatusUpdate(selectedTask.id, 'in-progress');
                    setSelectedTask(null);
                  }}
                >
                  Start Task
                </button>
              )}

              {!isAdmin && selectedTask.status === 'in-progress' && (
                <button
                  className={styles.actionBtn}
                  onClick={() => {
                    handleStatusUpdate(selectedTask.id, 'completed');
                    setSelectedTask(null);
                  }}
                >
                  Mark as Completed
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
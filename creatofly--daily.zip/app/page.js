'use client';

import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import Link from 'next/link';
import { initialTasks } from './data/tasks';
import { teamMembers as defaultMembers, currentUser as defaultUser } from './data/users';
import { getStoredTasks, saveStoredTasks, getStoredUsers } from './utils/storage';
import styles from './page.module.css';

const mockActivities = [
  {
    id: 1,
    taskId: 1,
    user: 'Rahul Kumar',
    action: 'completed task "Build Dashboard UI"',
    statusCategory: 'Completed',
    time: '10 mins ago',
    icon: '✅',
    bgColor: '#dcfce7',
    iconColor: '#15803d',
  },
  {
    id: 2,
    taskId: 2,
    user: 'Brijesh Singh',
    action: 'assigned task "Create Task Card Component" to Rahul',
    statusCategory: 'Assigned',
    time: '1 hour ago',
    icon: '📌',
    bgColor: '#f3e8ff',
    iconColor: '#7e22ce',
  },
  {
    id: 3,
    taskId: 3,
    user: 'Priya Sharma',
    action: 'started working on "Practice CSS Flexbox"',
    statusCategory: 'In Progress',
    time: '2 hours ago',
    icon: '⏳',
    bgColor: '#fef3c7',
    iconColor: '#b45309',
  },
  {
    id: 4,
    taskId: 4,
    user: 'Amit Patel',
    action: 'added new task "Read Next.js Documentation"',
    statusCategory: 'Added',
    time: '4 hours ago',
    icon: '➕',
    bgColor: '#e0f2fe',
    iconColor: '#0369a1',
  },
  {
    id: 5,
    taskId: 5,
    user: 'Rahul Kumar',
    action: 'completed task "Fix Responsive Layout Issue"',
    statusCategory: 'Completed',
    time: 'Yesterday',
    icon: '✅',
    bgColor: '#dcfce7',
    iconColor: '#15803d',
  },
];

export default function Home() {
  const [tasks, setTasks] = useState(initialTasks);
  const [teamMembers, setTeamMembers] = useState(defaultMembers);
  const [currentUser, setCurrentUser] = useState(defaultUser);
  const [isLoaded, setIsLoaded] = useState(false);

  // Modal and Filter States
  const [showAllActivities, setShowAllActivities] = useState(false);
  const [activityFilter, setActivityFilter] = useState('All');
  const [inspectTask, setInspectTask] = useState(null);

  useEffect(() => {
    setTasks(getStoredTasks(initialTasks));
    setTeamMembers(getStoredUsers(defaultMembers));

    const savedUser = localStorage.getItem('creatofly_active_user');
    if (savedUser) {
      try {
        setCurrentUser(JSON.parse(savedUser));
      } catch (e) {
        console.error('Error loading active user', e);
      }
    }
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    function handleUserSwitch() {
      setTeamMembers(getStoredUsers(defaultMembers));
      const savedUser = localStorage.getItem('creatofly_active_user');
      if (savedUser) {
        try {
          setCurrentUser(JSON.parse(savedUser));
        } catch (e) {
          console.error('Error reloading user', e);
        }
      }
    }
    window.addEventListener('activeUserChanged', handleUserSwitch);
    return () => window.removeEventListener('activeUserChanged', handleUserSwitch);
  }, []);

  function handleToggleTask(taskId) {
    const updated = tasks.map((t) => {
      if (t.id === taskId) {
        return { ...t, status: t.status === 'completed' ? 'pending' : 'completed' };
      }
      return t;
    });
    setTasks(updated);
    saveStoredTasks(updated);
  }

  const filteredActivities = mockActivities.filter((act) => {
    if (activityFilter === 'All') return true;
    return act.statusCategory.toLowerCase() === activityFilter.toLowerCase();
  });

  function handleSeeTask(taskId, e) {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    const found = tasks.find((t) => t.id === taskId) || {
      id: taskId,
      title: `Task #${taskId} Activity Log`,
      description: 'Activity details for task execution in workspace.',
      status: 'in-progress',
      dueDate: 'Jun 20, 2026',
      assignedBy: 1,
      assignedTo: 2,
    };
    setInspectTask(found);
  }

  // Admin and Role Check
  const isAdmin = currentUser?.role?.toLowerCase() === 'admin';

  // TASK FILTERING:
  // For Admin: Includes personal tasks (owned/created by Admin) PLUS tasks assigned by Admin to team members or to Admin
  // For Member: Includes tasks assigned to or owned by the user
  const relevantTasks = tasks.filter((t) => {
    const userIdStr = String(currentUser?.id);
    if (isAdmin) {
      return (
        String(t.assignedTo) === userIdStr ||
        String(t.assignedBy) === userIdStr ||
        String(t.ownerId) === userIdStr
      );
    }
    return String(t.assignedTo) === userIdStr || String(t.ownerId) === userIdStr;
  });

  // Statistics Calculations based on Admin's combined tasks (My Tasks + Assigned Tasks)
  const totalTasks = relevantTasks.length;
  const completedTasks = relevantTasks.filter((t) => t.status === 'completed').length;
  const pendingTasks = relevantTasks.filter((t) => t.status === 'pending').length;

  // Personal tasks added/owned by the logged-in user
  const myTasksCount = tasks.filter(
    (t) => (t.ownerId === currentUser?.id || t.type === 'personal') && t.assignedTo === currentUser?.id
  ).length;

  // Tasks assigned TO the current user specifically by an admin (excluding personal/self tasks)
  const assignedToMeCount = tasks.filter((t) => {
    const userIdStr = String(currentUser?.id);
    
    // 1. Must be assigned to current user, but NOT created/assigned by self or marked as personal
    const isAssignedToUser = String(t.assignedTo) === userIdStr;
    const isNotPersonal = t.type !== 'personal' && String(t.assignedBy) !== userIdStr && t.assignedBy !== 'self';
    
    if (!isAssignedToUser || !isNotPersonal) return false;

    // 2. Check if the assigner is an Admin
    const assigner = teamMembers.find((m) => String(m.id) === String(t.assignedBy));
    const isAdminAssigner = assigner?.role?.toLowerCase() === 'admin';

    return isAdminAssigner;
  }).length;

  // Tasks assigned BY admin to team members
  const assignedByMeCount = tasks.filter(
    (t) => t.assignedBy === currentUser?.id && t.assignedTo !== currentUser?.id
  ).length;

  const progressPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  const todayTasksList = relevantTasks.slice(0, 4);
  const deadlineTasks = relevantTasks.filter((t) => t.status === 'pending').slice(0, 3);

  if (!isLoaded) return <div className={styles.dashboardContainer}>Loading Dashboard...</div>;

  return (
    <div className={styles.dashboardContainer}>
      {/* Header */}
      <div className={styles.topBanner}>
        <div>
          <h1 className={styles.greetingHeader}>Good Morning, {currentUser?.name?.split(' ')[0] || 'User'}! 👋</h1>
          <p className={styles.subGreeting}>
            {isAdmin
              ? "Here is your personal and assigned task overview."
              : "Here's an overview of your tasks and progress for today."}
          </p>
        </div>
        <div className={styles.dateWidget}>
          <div className={styles.dateText}>Mon, 16 Jun 2026</div>
          <div>Let's make today productive!</div>
        </div>
      </div>

      {/* Top Stats Cards */}
      <div className={styles.statsGrid}>
        <div className={styles.statCard}>
          <div className={styles.statIcon} style={{ background: '#eff6ff', color: '#2563eb' }}>📋</div>
          <div className={styles.statInfo}>
            <span className={styles.statLabel}>Total Tasks</span>
            <span className={styles.statValue}>{totalTasks}</span>
          </div>
        </div>

        <div className={styles.statCard}>
          <div className={styles.statIcon} style={{ background: '#fffbeb', color: '#d97706' }}>🕒</div>
          <div className={styles.statInfo}>
            <span className={styles.statLabel}>Pending</span>
            <span className={styles.statValue}>{pendingTasks}</span>
          </div>
        </div>

        <div className={styles.statCard}>
          <div className={styles.statIcon} style={{ background: '#f0fdf4', color: '#16a34a' }}>✅</div>
          <div className={styles.statInfo}>
            <span className={styles.statLabel}>Completed</span>
            <span className={styles.statValue}>{completedTasks}</span>
          </div>
        </div>

        <div className={styles.statCard}>
          <div className={styles.statIcon} style={{ background: '#e0f2fe', color: '#0284c7' }}>📝</div>
          <div className={styles.statInfo}>
            <span className={styles.statLabel}>My Tasks</span>
            <span className={styles.statValue}>{myTasksCount}</span>
          </div>
        </div>

        {/* Card 5: Role-Aware Assigned Task Breakdown */}
        <div className={styles.statCard}>
          <div className={styles.statIcon} style={{ background: '#f3e8ff', color: '#9333ea' }}>👤</div>
          <div className={styles.statInfo}>
            <span className={styles.statLabel}>
              {isAdmin ? 'Tasks Assigned' : 'Assigned to You'}
            </span>
            <span className={styles.statValue}>
              {isAdmin ? assignedByMeCount : assignedToMeCount}
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid Layout */}
      <div className={styles.mainContentLayout}>
        {/* Left Column */}
        <div className={styles.leftColumn}>
          <div className={styles.analyticsRow}>
            {/* Donut Chart */}
            <div className={styles.card}>
              <div className={styles.cardHeader}>
                <span className={styles.cardTitle}>Task Progress</span>
              </div>
              <div className={styles.donutContainer}>
                <div
                  className={styles.donutRing}
                  style={{ background: `conic-gradient(#10b981 ${progressPercentage}%, #e2e8f0 0)` }}
                >
                  <div className={styles.donutInner}>
                    <span className={styles.percentageText}>{progressPercentage}%</span>
                    <span className={styles.percentageLabel}>Completed</span>
                  </div>
                </div>
                <div className={styles.legendList}>
                  <div className={styles.legendItem}>
                    <span className={styles.dot} style={{ background: '#10b981' }} />
                    <span>Completed ({completedTasks})</span>
                  </div>
                  <div className={styles.legendItem}>
                    <span className={styles.dot} style={{ background: '#f59e0b' }} />
                    <span>Pending ({pendingTasks})</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bar Chart */}
            <div className={styles.card}>
              <div className={styles.cardHeader}>
                <span className={styles.cardTitle}>Tasks by Status</span>
              </div>
              <div className={styles.barChartContainer}>
                <div className={styles.barGroup}>
                  <span className={styles.barValue}>{completedTasks}</span>
                  <div className={styles.bar} style={{ height: `${Math.min(completedTasks * 15 + 15, 80)}px`, background: '#10b981' }} />
                  <span className={styles.barLabel}>Completed</span>
                </div>
                <div className={styles.barGroup}>
                  <span className={styles.barValue}>{pendingTasks}</span>
                  <div className={styles.bar} style={{ height: `${Math.min(pendingTasks * 15 + 15, 80)}px`, background: '#f59e0b' }} />
                  <span className={styles.barLabel}>Pending</span>
                </div>
              </div>
            </div>
          </div>

          {/* Today's Tasks & Deadlines */}
          <div className={styles.tasksRow}>
            <div className={styles.card}>
              <div className={styles.cardHeader}>
                <span className={styles.cardTitle}>Today's Tasks</span>
                <Link href="/tasks" className={styles.viewAll}>View All</Link>
              </div>
              <div className={styles.taskList}>
                {todayTasksList.length > 0 ? (
                  todayTasksList.map((task) => (
                    <div key={task.id} className={styles.taskRow}>
                      <label className={styles.taskCheckboxLabel}>
                        <input
                          type="checkbox"
                          checked={task.status === 'completed'}
                          onChange={() => handleToggleTask(task.id)}
                        />
                        <span className={task.status === 'completed' ? styles.strikeThrough : undefined}>
                          {task.title}
                        </span>
                      </label>
                      <span className={`${styles.badge} ${task.status === 'completed' ? styles.completedBadge : styles.pendingBadge}`}>
                        {task.status}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className={styles.emptyText}>No tasks found.</div>
                )}
              </div>
            </div>

            <div className={styles.card}>
              <div className={styles.cardHeader}>
                <span className={styles.cardTitle}>Upcoming Deadlines</span>
                <Link href="/assigned-tasks" className={styles.viewAll}>View All</Link>
              </div>
              <div>
                {deadlineTasks.length > 0 ? (
                  deadlineTasks.map((task) => {
                    const assignee = teamMembers.find((m) => m.id === task.assignedTo);
                    return (
                      <div key={task.id} className={styles.deadlineRow}>
                        <div>
                          <div className={styles.deadlineTitle}>{task.title}</div>
                          <div className={styles.deadlineMeta}>
                            Assigned to {assignee ? assignee.name : 'You'}
                          </div>
                        </div>
                        <div className={styles.deadlineDate}>
                          <div className={styles.dateVal}>{task.dueDate || 'Jun 20'}</div>
                          <div className={styles.daysLeft}>Upcoming</div>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className={styles.emptyText}>No upcoming deadlines found.</div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className={styles.rightColumn}>
          <div className={styles.card}>
            <div className={styles.cardHeader}>
              <span className={styles.cardTitle}>Recent Activity</span>
              <button
                type="button"
                className={styles.viewAllBtn}
                onClick={() => setShowAllActivities(true)}
              >
                View All
              </button>
            </div>
            <div className={styles.activityList}>
              {mockActivities.slice(0, 3).map((act) => (
                <div key={act.id} className={styles.activityItemSpaceBetween}>
                  <div className={styles.activityItemGroup}>
                    <div className={styles.activityIcon} style={{ background: act.bgColor, color: act.iconColor }}>
                      {act.icon}
                    </div>
                    <div>
                      <div className={styles.activityText}><b>{act.user}</b> {act.action}</div>
                      <div className={styles.activityTime}>{act.time}</div>
                    </div>
                  </div>
                  <button
                    type="button"
                    className={styles.seeTaskBtn}
                    onClick={(e) => handleSeeTask(act.taskId, e)}
                  >
                    See Task
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className={styles.quoteCard}>
            <div className={styles.quoteText}>"Stay consistent, progress will follow."</div>
            <div className={styles.quoteAuthor}>— Creatofly Daily</div>
          </div>
        </div>
      </div>

      {/* Modals */}
      {showAllActivities && isLoaded && createPortal(
        <ActivityModal
          activityFilter={activityFilter}
          setActivityFilter={setActivityFilter}
          filteredActivities={filteredActivities}
          onClose={() => setShowAllActivities(false)}
          onSeeTask={handleSeeTask}
        />,
        document.body
      )}

      {inspectTask && isLoaded && createPortal(
        <InspectTaskModal
          inspectTask={inspectTask}
          onClose={() => setInspectTask(null)}
        />,
        document.body
      )}
    </div>
  );
}

// Activity Modal Sub-component
function ActivityModal({ activityFilter, setActivityFilter, filteredActivities, onClose, onSeeTask }) {
  return (
    <div className={styles.modalOverlay} onClick={onClose}>
      <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
        <div className={styles.modalHeader}>
          <h3 className={styles.modalTitle}>All Recent Workspace Activities</h3>
          <button type="button" className={styles.closeBtn} onClick={onClose}>✕</button>
        </div>

        <div className={styles.filterPillGroup}>
          {['All', 'Added', 'Completed', 'In Progress', 'Assigned'].map((cat) => (
            <button
              key={cat}
              type="button"
              className={`${styles.filterPill} ${activityFilter === cat ? styles.filterPillActive : ''}`}
              onClick={() => setActivityFilter(cat)}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className={styles.activityModalList}>
          {filteredActivities.length > 0 ? (
            filteredActivities.map((act) => (
              <div key={act.id} className={styles.activityModalRow}>
                <div className={styles.activityItemGroup}>
                  <div className={styles.activityModalIcon} style={{ background: act.bgColor, color: act.iconColor }}>
                    {act.icon}
                  </div>
                  <div>
                    <div className={styles.activityModalText}>
                      <b>{act.user}</b> {act.action}
                    </div>
                    <div className={styles.activityModalTime}>🕒 {act.time}</div>
                  </div>
                </div>
                <button
                  type="button"
                  className={styles.seeTaskBtnModal}
                  onClick={(e) => onSeeTask(act.taskId, e)}
                >
                  See Task
                </button>
              </div>
            ))
          ) : (
            <div className={styles.emptyTextCenter}>No activities found for this category.</div>
          )}
        </div>
      </div>
    </div>
  );
}

// Task Inspection Modal Sub-component
function InspectTaskModal({ inspectTask, onClose }) {
  return (
    <div className={styles.darkModalOverlay} onClick={onClose}>
      <div className={styles.compactModalContent} onClick={(e) => e.stopPropagation()}>
        <div className={styles.modalHeader}>
          <h3 className={styles.compactModalTitle}>Task Details</h3>
          <button type="button" className={styles.closeBtnSmall} onClick={onClose}>✕</button>
        </div>

        <div className={styles.detailGroup}>
          <div className={styles.detailLabel}>TASK TITLE</div>
          <div className={styles.detailTitle}>{inspectTask.title}</div>
        </div>

        <div className={styles.detailGroup}>
          <div className={styles.detailLabel}>DESCRIPTION</div>
          <div className={styles.detailText}>
            {inspectTask.description || 'Details regarding this activity log.'}
          </div>
        </div>

        <div className={styles.detailGrid}>
          <div>
            <div className={styles.detailLabel}>DUE DATE</div>
            <div className={styles.detailVal}>{inspectTask.dueDate || 'Jun 20, 2026'}</div>
          </div>
          <div>
            <div className={styles.detailLabel}>STATUS</div>
            <div className={styles.detailStatusVal}>{inspectTask.status}</div>
          </div>
        </div>

        <button type="button" className={styles.primaryModalBtn} onClick={onClose}>
          Close
        </button>
      </div>
    </div>
  );
}
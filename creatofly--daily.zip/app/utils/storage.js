const TASKS_STORAGE_KEY = 'creatofly_tasks';
const USERS_STORAGE_KEY = 'creatofly_team_members';
// Storage keys
const TASKS_KEY = 'creatofly_tasks';
const TRASH_KEY = 'creatofly_trash_tasks';

// --- Task Storage Utilities ---

export function getStoredTasks(defaultTasks) {
  if (typeof window === 'undefined') return defaultTasks;
  const stored = localStorage.getItem(TASKS_STORAGE_KEY);
  return stored ? JSON.parse(stored) : defaultTasks;
}

export function saveStoredTasks(tasks) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(TASKS_STORAGE_KEY, JSON.stringify(tasks));
}

// --- Team Member Storage Utilities ---

export function getStoredUsers(defaultUsers) {
  if (typeof window === 'undefined') return defaultUsers;
  const stored = localStorage.getItem(USERS_STORAGE_KEY);
  return stored ? JSON.parse(stored) : defaultUsers;
}

export function saveStoredUsers(users) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
}



export function getStoredTrash() {
  if (typeof window === 'undefined') return [];
  try {
    const data = localStorage.getItem(TRASH_KEY);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error('Error loading trash tasks from localStorage', e);
    return [];
  }
}

export function saveStoredTrash(trashTasks) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(TRASH_KEY, JSON.stringify(trashTasks));
  } catch (e) {
    console.error('Error saving trash tasks to localStorage', e);
  }
}
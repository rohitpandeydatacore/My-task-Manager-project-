import Link from 'next/link';
import styles from './Sidebar.module.css';

export default function Sidebar() {
  return (
    <aside className={styles.sidebar}>
      <div className={styles.logo}>Creatofly Daily</div>
      <nav className={styles.nav}>
        <Link href="/" className={styles.navLink}>
          Dashboard
        </Link>
        <Link href="/tasks" className={styles.navLink}>
          My Tasks
        </Link>
        <Link href="/assigned-tasks" className={styles.navLink}>
          Assigned Tasks
        </Link>
        <Link href="/team" className={styles.navLink}>
          Team
        </Link>
      </nav>
    </aside>
  );
}
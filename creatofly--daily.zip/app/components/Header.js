'use client';

import { useState, useEffect } from 'react';
import { teamMembers as defaultMembers } from '../data/users';
import { getStoredUsers } from '../utils/storage';
import styles from './Header.module.css';

export default function Header() {
  const [teamMembers, setTeamMembers] = useState(defaultMembers);
  const [activeUser, setActiveUser] = useState(defaultMembers[0]);

  // Sync team members and active user from storage
  useEffect(() => {
    const storedUsers = getStoredUsers(defaultMembers);
    setTeamMembers(storedUsers);

    const savedUser = localStorage.getItem('creatofly_active_user');
    if (savedUser) {
      try {
        setActiveUser(JSON.parse(savedUser));
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  // Sync active user changes from custom events
  useEffect(() => {
    function syncUser() {
      const storedUsers = getStoredUsers(defaultMembers);
      setTeamMembers(storedUsers);

      const savedUser = localStorage.getItem('creatofly_active_user');
      if (savedUser) {
        try {
          setActiveUser(JSON.parse(savedUser));
        } catch (e) {
          console.error(e);
        }
      }
    }

    window.addEventListener('activeUserChanged', syncUser);
    return () => window.removeEventListener('activeUserChanged', syncUser);
  }, []);

  function handleUserChange(e) {
    const selected = teamMembers.find((m) => m.id === Number(e.target.value));
    if (!selected) return;

    setActiveUser(selected);
    localStorage.setItem('creatofly_active_user', JSON.stringify(selected));

    window.dispatchEvent(new Event('activeUserChanged'));
  }

  return (
    <header className={styles.header}>
      <div className={styles.titleSection}>
        <h1 className={styles.heading}>Creatofly Daily</h1>
      </div>

      <div className={styles.userSection}>
        <label htmlFor="userSelect" className={styles.label}>
          Active User:
        </label>
        <select
          id="userSelect"
          className={styles.select}
          value={activeUser.id}
          onChange={handleUserChange}
        >
          {teamMembers.map((member) => (
            <option key={member.id} value={member.id}>
              {member.avatar} {member.name} ({member.role})
            </option>
          ))}
        </select>
      </div>
    </header>
  );
}
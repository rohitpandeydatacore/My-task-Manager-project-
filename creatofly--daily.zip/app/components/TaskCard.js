'use client';

import { useState } from 'react';
import styles from './TaskCard.module.css';

export default function TaskCard({
  task,
  currentUser,
  teamMembers = [],
  onToggleStatus,
  onToggleSubtask,
  onDelete,
  onEdit,
}) {
  const [showDetailModal, setShowDetailModal] = useState(false);
  const isCompleted = task.status === 'completed';

  const subtasks = task.subtasks || [];
  const completedSubtasksCount = subtasks.filter((st) => st.completed).length;
  const assignee = teamMembers.find((m) => m.id === task.assignedTo);

  const getPriorityClass = (priority) => {
    if (priority === 'high') return styles.pHigh;
    if (priority === 'low') return styles.pLow;
    return styles.pMedium;
  };

  return (
    <>
      <div className={styles.card}>
        <div className={styles.topRow}>
          <div className={styles.leftSection}>
            <input
              type="checkbox"
              checked={isCompleted}
              onChange={() => onToggleStatus(task.id)}
              className={styles.checkbox}
            />
            <span className={`${styles.title} ${isCompleted ? styles.completedTitle : ''}`}>
              {task.title}
            </span>
          </div>

          <div className={styles.actions}>
            <button className={styles.iconBtn} onClick={() => setShowDetailModal(true)}>
              👁 View
            </button>
            <button className={styles.iconBtn} onClick={() => onEdit(task)}>
              ✎ Edit
            </button>
            <button
              className={`${styles.iconBtn} ${styles.deleteBtn}`}
              onClick={() => onDelete(task.id)}
            >
              🗑 Delete
            </button>
          </div>
        </div>

        {/* Task Details Banner */}
        <div className={styles.metaRow}>
          {task.priority && (
            <span className={`${styles.badge} ${getPriorityClass(task.priority)}`}>
              Priority: {task.priority.toUpperCase()}
            </span>
          )}
          {task.dueDate && <span>📅 Due: {task.dueDate}</span>}
          {task.duration && <span>⏱ Est: {task.duration}</span>}
          {assignee && <span>👤 {assignee.name}</span>}
          {subtasks.length > 0 && (
            <span className={styles.subtaskCount}>
              Subtasks: {completedSubtasksCount}/{subtasks.length}
            </span>
          )}
        </div>
      </div>

      {/* Full View Detail Modal */}
      {showDetailModal && (
        <div className={styles.modalOverlay} onClick={() => setShowDetailModal(false)}>
          <div className={styles.detailModal} onClick={(e) => e.stopPropagation()}>
            <h3>{task.title}</h3>
            <p style={{ color: '#64748b', fontSize: '14px', marginTop: '6px' }}>
              {task.description || 'No description provided.'}
            </p>

            <div className={styles.detailGrid}>
              <div><strong>Status:</strong> {task.status}</div>
              <div><strong>Priority:</strong> {task.priority || 'N/A'}</div>
              <div><strong>Due Date:</strong> {task.dueDate || 'N/A'}</div>
              <div><strong>Duration:</strong> {task.duration || 'N/A'}</div>
              <div><strong>Assigned To:</strong> {assignee?.name || 'Unassigned'}</div>
              <div><strong>Type:</strong> {task.type}</div>
            </div>

            {subtasks.length > 0 && (
              <div>
                <strong style={{ fontSize: '14px' }}>
                  Subtasks ({completedSubtasksCount}/{subtasks.length}):
                </strong>
                <ul className={styles.modalSubtasks}>
                  {subtasks.map((st) => {
                    const isSubtaskChecked = isCompleted || st.completed;
                    return (
                      <li key={st.id} className={styles.modalSubtaskItem}>
                        <input
                          type="checkbox"
                          checked={isSubtaskChecked}
                          onChange={() => onToggleSubtask && onToggleSubtask(task.id, st.id)}
                        />
                        <span
                          style={{
                            textDecoration: isSubtaskChecked ? 'line-through' : 'none',
                            color: isSubtaskChecked ? '#94a3b8' : '#0f172a',
                          }}
                        >
                          {st.title} {isSubtaskChecked && '✓'}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              </div>
            )}

            <button className={styles.closeBtn} onClick={() => setShowDetailModal(false)}>
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
}
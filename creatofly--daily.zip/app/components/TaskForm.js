'use client';

import { useState, useEffect } from 'react';
import styles from './TaskForm.module.css';

export default function TaskForm({
  isOpen,
  onClose,
  onSubmit,
  initialTask,
  isAssignedMode = false,
  teamMembers = [],
}) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState('medium');
  const [dueDate, setDueDate] = useState('');
  const [duration, setDuration] = useState('');
  const [assignedTo, setAssignedTo] = useState(1);
  const [subtasks, setSubtasks] = useState([]);
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');

  // Fixed constant dependency array [isOpen, initialTask]
  useEffect(() => {
    if (isOpen && initialTask) {
      setTitle(initialTask.title || '');
      setDescription(initialTask.description || '');
      setPriority(initialTask.priority || 'medium');
      setDueDate(initialTask.dueDate || '');
      setDuration(initialTask.duration || '');
      setAssignedTo(initialTask.assignedTo || 1);
      setSubtasks(initialTask.subtasks || []);
    } else if (!isOpen) {
      setTitle('');
      setDescription('');
      setPriority('medium');
      setDueDate('');
      setDuration('');
      setAssignedTo(1);
      setSubtasks([]);
      setNewSubtaskTitle('');
    }
  }, [isOpen, initialTask]); // Always exactly 2 items on every render

  if (!isOpen) return null;

  function handleAddSubtask() {
    if (!newSubtaskTitle.trim()) return;
    setSubtasks([...subtasks, { id: Date.now(), title: newSubtaskTitle, completed: false }]);
    setNewSubtaskTitle('');
  }

  function handleRemoveSubtask(id) {
    setSubtasks(subtasks.filter((st) => st.id !== id));
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!title.trim()) return;

    onSubmit({
      title,
      description,
      priority,
      dueDate,
      duration,
      assignedTo: Number(assignedTo),
      subtasks,
    });

    onClose();
  }

  return (
    <div className={styles.overlay}>
      <div className={styles.modal}>
        <h3 className={styles.title}>{initialTask ? 'Edit Task' : 'Create Task'}</h3>
        <form onSubmit={handleSubmit}>
          <div className={styles.formGroup}>
            <label className={styles.label}>Task Title *</label>
            <input
              type="text"
              className={styles.input}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Finish daily progress report"
              required
            />
          </div>

          <div className={styles.formGroup}>
            <label className={styles.label}>Description</label>
            <textarea
              className={styles.textarea}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Task context, details, notes..."
            />
          </div>

          <div className={styles.rowGroup}>
            <div className={styles.formGroup}>
              <label className={styles.label}>Priority</label>
              <select
                className={styles.input}
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
              >
                <option value="high">🔥 High</option>
                <option value="medium">⚡ Medium</option>
                <option value="low">🟢 Low</option>
              </select>
            </div>

            <div className={styles.formGroup}>
              <label className={styles.label}>Due Date</label>
              <input
                type="date"
                className={styles.input}
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
            </div>
          </div>

          <div className={styles.rowGroup}>
            <div className={styles.formGroup}>
              <label className={styles.label}>Estimated Duration</label>
              <input
                type="text"
                className={styles.input}
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                placeholder="e.g. 2 hours, 1 day, 30 mins"
              />
            </div>

            {isAssignedMode && (
              <div className={styles.formGroup}>
                <label className={styles.label}>Assign To Team Member</label>
                <select
                  className={styles.input}
                  value={assignedTo}
                  onChange={(e) => setAssignedTo(e.target.value)}
                >
                  {teamMembers.map((member) => (
                    <option key={member.id} value={member.id}>
                      {member.avatar} {member.name} ({member.role})
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* Sub-tasks Section */}
          <div className={styles.subtaskSection}>
            <label className={styles.label}>Sub-tasks / Breakdowns</label>
            <div className={styles.subtaskInputRow}>
              <input
                type="text"
                className={styles.input}
                value={newSubtaskTitle}
                onChange={(e) => setNewSubtaskTitle(e.target.value)}
                placeholder="Add step/sub-task..."
              />
              <button type="button" className={styles.addSubtaskBtn} onClick={handleAddSubtask}>
                + Add
              </button>
            </div>

            {subtasks.length > 0 && (
              <ul className={styles.subtaskList}>
                {subtasks.map((st) => (
                  <li key={st.id} className={styles.subtaskItem}>
                    <span>{st.title}</span>
                    <button
                      type="button"
                      className={styles.removeSubtaskBtn}
                      onClick={() => handleRemoveSubtask(st.id)}
                    >
                      ✕
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className={styles.actions}>
            <button type="button" className={styles.cancelBtn} onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className={styles.submitBtn}>
              {initialTask ? 'Save Changes' : 'Create Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
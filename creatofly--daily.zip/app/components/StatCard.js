import styles from './StatCard.module.css';

// Receiving props: 'title' and 'value' passed from the parent
export default function StatCard({ title, value }) {
  return (
    <div className={styles.card}>
      <div className={styles.title}>{title}</div>
      <div className={styles.value}>{value}</div>
    </div>
  );
}
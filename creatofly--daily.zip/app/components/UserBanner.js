import styles from './UserBanner.module.css';

export default function UserBanner({ currentUser }) {
  const isAdmin = currentUser.role === 'admin';

  return (
    <div className={`${styles.banner} ${isAdmin ? styles.adminBanner : styles.memberBanner}`}>
      <div>
        <strong>Logged in as:</strong> {currentUser.avatar} {currentUser.name}
        <span className={`${styles.roleBadge} ${isAdmin ? styles.adminBadge : styles.memberBadge}`}>
          {currentUser.role}
        </span>
      </div>
      <span style={{ fontSize: '13px' }}>
        {isAdmin
          ? '⚡ You have full management access (Edit, Delete, Assign across all tasks).'
          : '🔒 You can manage your own tasks and view peer tasks.'}
      </span>
    </div>
  );
}
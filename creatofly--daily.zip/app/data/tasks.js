export const initialTasks = [
  {
    id: 1,
    title: 'Complete Next.js Layout',
    description: 'Set up responsive sidebar, header, and user switcher.',
    type: 'personal', // 'personal' or 'assigned'
    ownerId: 1, // User who created it
    assignedTo: 1, // Active user
    assignedBy: 1, // Self-assigned
    status: 'pending', // 'pending' | 'completed'
    priority: 'high', // 'high' | 'medium' | 'low'
    dueDate: '2026-09-20',
    duration: '2 hours',
    subtasks: [
      { id: 101, title: 'Build Header', completed: true },
      { id: 102, title: 'Build User Switcher', completed: false },
    ],
    createdAt: '2026-09-18',
  },
  {
    id: 2,
    title: 'Design Team Dashboard Mockup',
    description: 'Prepare high-fidelity UI design for admin review.',
    type: 'assigned',
    ownerId: 1,
    assignedTo: 2, // Assigned to Alex Johnson
    assignedBy: 1, // Assigned by Admin Brijesh
    status: 'pending',
    priority: 'medium',
    dueDate: '2026-09-25',
    duration: '1 day',
    subtasks: [],
    createdAt: '2026-09-18',
  },
];
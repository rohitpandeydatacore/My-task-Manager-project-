export const teamMembers = [
  {
    id: 1,
    name: "Brijesh",
    email: "brijesh@creatofly.com",
    role: "admin",
    avatar: "👑",
  },
  {
    id: 2,
    name: "Alex Johnson",
    email: "alex@creatofly.com",
    role: "member",
    avatar: "👤",
  },
  {
    id: 3,
    name: "Sarah Smith",
    email: "sarah@creatofly.com",
    role: "member",
    avatar: "👤",
  },
  {
    id: 4,
    name: "David Lee",
    email: "david@creatofly.com",
    role: "member",
    avatar: "👤",
  },
];

// Current logged-in user simulation (Default: Admin Brijesh)
export const currentUser = teamMembers[0];
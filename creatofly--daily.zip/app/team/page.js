'use client';

import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { teamMembers as defaultMembers, currentUser as defaultUser } from '../data/users';
import { initialTasks } from '../data/tasks';
import { getStoredTasks, getStoredUsers, saveStoredTasks, saveStoredUsers } from '../utils/storage';
import styles from './team.module.css';

const mockActivities = [
  { id: 1, user: 'You', action: 'assigned a task to Rahul', detail: 'Build Dashboard UI', time: '2 hours ago', icon: '👤', bgColor: '#f3e8ff', iconColor: '#9333ea', category: 'Assigned' },
  { id: 2, user: 'Aditya', action: 'completed a task', detail: 'Practice CSS Flexbox', time: '4 hours ago', icon: '✅', bgColor: '#dcfce7', iconColor: '#16a34a', category: 'Completed' },
  { id: 3, user: 'System', action: 'New team member added', detail: 'Sneha Verma joined the team', time: '1 day ago', icon: '➕', bgColor: '#e0f2fe', iconColor: '#0284c7', category: 'Added' },
  { id: 4, user: 'Vivek', action: 'completed a task', detail: 'Read Next.js Documentation', time: '1 day ago', icon: '✅', bgColor: '#dcfce7', iconColor: '#16a34a', category: 'Completed' },
  { id: 5, user: 'You', action: 'assigned a task to Aditya', detail: 'Create Task Form', time: '2 days ago', icon: '👤', bgColor: '#f3e8ff', iconColor: '#9333ea', category: 'Assigned' }
];

export default function TeamPage() {
  const router = useRouter();
  const [tasks, setTasks] = useState(initialTasks);
  const [members, setMembers] = useState(defaultMembers);
  const [currentUser, setCurrentUser] = useState(defaultUser);
  const [isLoaded, setIsLoaded] = useState(false);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('progress');

  // Edit Team Members Modal State
  const [showEditMembersModal, setShowEditMembersModal] = useState(false);
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberRole, setNewMemberRole] = useState('Developer');

  // User Self-Rename State
  const [userRenameValue, setUserRenameValue] = useState('');

  // Assign Task Modal State
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [assignedMemberId, setAssignedMemberId] = useState('');

  // Task Form State (Admin)
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskDescription, setNewTaskDescription] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState('⚡ Medium');
  const [newTaskDueDate, setNewTaskDueDate] = useState('');
  const [estimatedDuration, setEstimatedDuration] = useState('');

  // Sub-tasks State
  const [subtasksInput, setSubtasksInput] = useState([]);
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');

  const [showAllActivities, setShowAllActivities] = useState(false);
  const [activityFilter, setActivityFilter] = useState('All');

  const [activeMenuMemberId, setActiveMenuMemberId] = useState(null);
  const [viewMemberTasks, setViewMemberTasks] = useState(null);
  const [showKeepGoingModal, setShowKeepGoingModal] = useState(false);

  useEffect(() => {
    setTasks(getStoredTasks(initialTasks));
    const storedUsers = getStoredUsers(defaultMembers);
    setMembers(storedUsers);

    const savedUser = localStorage.getItem('creatofly_active_user');
    if (savedUser) {
      try {
        const parsed = JSON.parse(savedUser);
        setCurrentUser(parsed);
        setUserRenameValue(parsed.name || '');
      } catch (e) {
        console.error('Error loading user', e);
      }
    }
    setIsLoaded(true);
  }, []);

  // Admin Role Check
  const isAdmin = currentUser?.role?.toLowerCase() === 'admin';

  // Dynamic Metrics
  const totalMembers = members.length;
  const totalTasks = tasks.length;
  const pendingTasks = tasks.filter((t) => t.status === 'pending').length;
  const completedTasks = tasks.filter((t) => t.status === 'completed').length;
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  // Build per-member task stats
  const memberStats = members.map((member) => {
    const memberTasks = tasks.filter((t) => t.assignedTo === member.id);
    const memberTotal = memberTasks.length;
    const memberCompleted = memberTasks.filter((t) => t.status === 'completed').length;
    const memberPending = memberTotal - memberCompleted;
    const memberProgress = memberTotal > 0 ? Math.round((memberCompleted / memberTotal) * 100) : 0;

    return {
      ...member,
      totalTasks: memberTotal,
      completed: memberCompleted,
      pending: memberPending,
      progress: memberProgress,
    };
  });

  // Filter & Sort members list
  const filteredMembers = memberStats
    .filter((m) => m.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => {
      if (sortBy === 'progress') return b.progress - a.progress;
      if (sortBy === 'tasks') return b.totalTasks - a.totalTasks;
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      return 0;
    });

  // Handle Admin Member Management (Add/Remove)
  function handleAddMember(e) {
    e.preventDefault();
    if (!newMemberName.trim()) return;

    const newMember = {
      id: Date.now(),
      name: newMemberName.trim(),
      role: newMemberRole,
      avatarBg: '#' + Math.floor(Math.random() * 16777215).toString(16),
    };

    const updatedMembers = [...members, newMember];
    setMembers(updatedMembers);
    saveStoredUsers(updatedMembers);
    setNewMemberName('');
  }

  function handleDeleteMember(id) {
    if (confirm('Are you sure you want to remove this team member?')) {
      const updatedMembers = members.filter((m) => m.id !== id);
      setMembers(updatedMembers);
      saveStoredUsers(updatedMembers);
    }
  }

  // Handle Self Name Update (User)
  function handleSelfRename(e) {
    e.preventDefault();
    if (!userRenameValue.trim() || !currentUser) return;

    const updatedMembers = members.map((m) => {
      if (String(m.id) === String(currentUser.id)) {
        return { ...m, name: userRenameValue.trim() };
      }
      return m;
    });

    const updatedUser = { ...currentUser, name: userRenameValue.trim() };

    setMembers(updatedMembers);
    setCurrentUser(updatedUser);
    saveStoredUsers(updatedMembers);
    localStorage.setItem('creatofly_active_user', JSON.stringify(updatedUser));
    alert('Your name has been updated successfully!');
  }

  // Task Assign Modal handlers
  function openAssignModal(memberId = '') {
    setAssignedMemberId(memberId ? String(memberId) : (members[0]?.id ? String(members[0].id) : ''));
    setNewTaskTitle('');
    setNewTaskDescription('');
    setNewTaskPriority('⚡ Medium');
    setNewTaskDueDate('');
    setEstimatedDuration('');
    setSubtasksInput([]);
    setNewSubtaskTitle('');
    setShowAssignModal(true);
    setActiveMenuMemberId(null);
  }

  function handleAddSubtask() {
    if (!newSubtaskTitle.trim()) return;
    setSubtasksInput([...subtasksInput, { id: Date.now(), title: newSubtaskTitle.trim(), completed: false }]);
    setNewSubtaskTitle('');
  }

  function handleRemoveSubtask(subtaskId) {
    setSubtasksInput(subtasksInput.filter((st) => st.id !== subtaskId));
  }

  function handleAssignTask(e) {
    e.preventDefault();
    if (!newTaskTitle.trim() || !assignedMemberId) return;

    let formattedDate = 'Jun 25, 2026';
    if (newTaskDueDate) {
      const dateObj = new Date(newTaskDueDate);
      formattedDate = dateObj.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
    }

    const targetMemberId = Number(assignedMemberId) || assignedMemberId;

    const newTask = {
      id: Date.now(),
      title: newTaskTitle,
      description: newTaskDescription,
      priority: newTaskPriority.replace('⚡ ', ''),
      assignedTo: targetMemberId,
      assignedBy: currentUser.id,
      ownerId: currentUser.id,
      status: 'pending',
      dueDate: formattedDate,
      type: 'assigned',
      estimatedDuration: estimatedDuration,
      subtasks: subtasksInput,
    };

    const updatedTasks = [newTask, ...tasks];
    setTasks(updatedTasks);
    saveStoredTasks(updatedTasks);

    setShowAssignModal(false);
  }

  // Context Menu Handlers
  function handleMarkAllCompleted(memberId) {
    if (!isAdmin && String(memberId) !== String(currentUser.id)) return;
    const updated = tasks.map((t) => {
      if (t.assignedTo === memberId) {
        return { ...t, status: 'completed' };
      }
      return t;
    });
    setTasks(updated);
    saveStoredTasks(updated);
    setActiveMenuMemberId(null);
  }

  function handleMarkAllPending(memberId) {
    if (!isAdmin && String(memberId) !== String(currentUser.id)) return;
    const updated = tasks.map((t) => {
      if (t.assignedTo === memberId) {
        return { ...t, status: 'pending' };
      }
      return t;
    });
    setTasks(updated);
    saveStoredTasks(updated);
    setActiveMenuMemberId(null);
  }

  function handleClearMemberTasks(memberId) {
    if (!isAdmin) return;
    if (confirm('Are you sure you want to remove all tasks assigned to this member?')) {
      const updated = tasks.filter((t) => t.assignedTo !== memberId);
      setTasks(updated);
      saveStoredTasks(updated);
    }
    setActiveMenuMemberId(null);
  }

  function handleSeeMemberTasks(member) {
    setViewMemberTasks(member);
    setActiveMenuMemberId(null);
  }

  if (!isLoaded) return <div className={styles.dashboardContainer}>Loading Team...</div>;

  return (
    <div className={styles.dashboardContainer} onClick={() => setActiveMenuMemberId(null)}>
      {/* Top Banner Header */}
      <div className={styles.topBanner}>
        <div>
          <h1 className={styles.greetingHeader}>Team</h1>
          <p className={styles.subGreeting}>Manage your team, track everyone's progress, and organize task flow.</p>
        </div>
        
        {/* Top-right corner Action Button replaced per request */}
        <button
          type="button"
          className={styles.primaryBtn}
          onClick={(e) => {
            e.stopPropagation();
            setShowEditMembersModal(true);
          }}
        >
          {isAdmin ? '✏️ Edit Team Members' : '✏️ Edit Profile'}
        </button>
      </div>

      {/* Top Summary Cards */}
      <div className={styles.statsGrid}>
        <div className={styles.statCard}>
          <div className={styles.statIcon} style={{ background: '#eff6ff', color: '#2563eb' }}>👥</div>
          <div className={styles.statInfo}>
            <span className={styles.statLabel}>Total Members</span>
            <span className={styles.statValue}>{totalMembers}</span>
            <span className={styles.statSubText} style={{ color: '#16a34a' }}>↑ +1 vs last month</span>
          </div>
        </div>

        <div className={styles.statCard}>
          <div className={styles.statIcon} style={{ background: '#f0fdf4', color: '#16a34a' }}>✅</div>
          <div className={styles.statInfo}>
            <span className={styles.statLabel}>Total Tasks</span>
            <span className={styles.statValue}>{totalTasks}</span>
            <span className={styles.statSubText} style={{ color: '#16a34a' }}>↑ +6 vs last week</span>
          </div>
        </div>

        <div className={styles.statCard}>
          <div className={styles.statIcon} style={{ background: '#fffbeb', color: '#d97706' }}>🕒</div>
          <div className={styles.statInfo}>
            <span className={styles.statLabel}>Pending Tasks</span>
            <span className={styles.statValue}>{pendingTasks}</span>
            <span className={styles.statSubText} style={{ color: '#dc2626' }}>↓ -2 vs last week</span>
          </div>
        </div>

        <div className={styles.statCard}>
          <div className={styles.statIcon} style={{ background: '#f3e8ff', color: '#9333ea' }}>📊</div>
          <div className={styles.statInfo}>
            <span className={styles.statLabel}>Completion Rate</span>
            <span className={styles.statValue}>{completionRate}%</span>
            <span className={styles.statSubText} style={{ color: '#16a34a' }}>↑ +8% vs last week</span>
          </div>
        </div>
      </div>

      {/* Main Content Layout */}
      <div className={styles.mainContentLayout}>
        {/* Left Column: Team Members */}
        <div className={styles.leftColumn}>
          <div className={styles.card}>
            <div className={styles.cardHeader} style={{ flexWrap: 'wrap', gap: '12px' }}>
              <div>
                <span className={styles.cardTitle}>Team Members</span>
                <p className={styles.subGreeting} style={{ margin: 0, fontSize: '12px' }}>
                  View progress and support your team members.
                </p>
              </div>

              {/* Search & Sort */}
              <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                <input
                  type="text"
                  placeholder="🔍 Search team members..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  style={{
                    padding: '6px 12px',
                    borderRadius: '8px',
                    border: '1px solid #cbd5e1',
                    fontSize: '13px',
                    outline: 'none',
                  }}
                />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  style={{
                    padding: '6px 12px',
                    borderRadius: '8px',
                    border: '1px solid #cbd5e1',
                    fontSize: '13px',
                    background: '#fff',
                    cursor: 'pointer',
                  }}
                >
                  <option value="progress">Sort by Progress</option>
                  <option value="tasks">Sort by Tasks Count</option>
                  <option value="name">Sort by Name</option>
                </select>
              </div>
            </div>

            {/* Member Cards */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '12px' }}>
              {filteredMembers.length > 0 ? (
                filteredMembers.map((member) => {
                  const isSelf = currentUser && String(member.id) === String(currentUser.id);

                  return (
                    <div
                      key={member.id}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        padding: '12px 16px',
                        background: '#f8fafc',
                        borderRadius: '10px',
                        border: '1px solid #e2e8f0',
                        flexWrap: 'wrap',
                        gap: '12px',
                        position: 'relative',
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', minWidth: '180px' }}>
                        <div
                          style={{
                            width: '38px',
                            height: '38px',
                            borderRadius: '50%',
                            background: member.avatarBg || '#2563eb',
                            color: '#fff',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontWeight: '700',
                            fontSize: '15px',
                          }}
                        >
                          {member.name.charAt(0)}
                        </div>
                        <div>
                          <div style={{ fontWeight: '700', fontSize: '14px', color: '#0f172a' }}>
                            {member.name} {isSelf && <span style={{ fontSize: '11px', color: '#2563eb' }}>(You)</span>}
                          </div>
                          <div style={{ fontSize: '12px', color: '#64748b' }}>{member.role || 'Team Member'}</div>
                        </div>
                      </div>

                      {/* Stats */}
                      <div style={{ display: 'flex', gap: '20px', textAlign: 'center' }}>
                        <div>
                          <div style={{ fontWeight: '700', fontSize: '14px' }}>{member.totalTasks}</div>
                          <div style={{ fontSize: '11px', color: '#64748b' }}>Total Tasks</div>
                        </div>
                        <div>
                          <div style={{ fontWeight: '700', fontSize: '14px', color: '#16a34a' }}>{member.completed}</div>
                          <div style={{ fontSize: '11px', color: '#64748b' }}>Completed</div>
                        </div>
                        <div>
                          <div style={{ fontWeight: '700', fontSize: '14px', color: '#d97706' }}>{member.pending}</div>
                          <div style={{ fontSize: '11px', color: '#64748b' }}>Pending</div>
                        </div>
                      </div>

                      {/* Progress Bar */}
                      <div style={{ minWidth: '130px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', fontWeight: '600', marginBottom: '4px' }}>
                          <span>{member.progress}%</span>
                        </div>
                        <div style={{ width: '100%', height: '8px', background: '#e2e8f0', borderRadius: '4px', overflow: 'hidden' }}>
                          <div
                            style={{
                              width: `${member.progress}%`,
                              height: '100%',
                              background: '#10b981',
                              borderRadius: '4px',
                              transition: 'width 0.3s ease',
                            }}
                          ></div>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div style={{ display: 'flex', gap: '8px', alignItems: 'center', position: 'relative' }}>
                        {!isAdmin && isSelf && (
                          <button
                            type="button"
                            style={{
                              background: '#f0fdf4',
                              color: '#16a34a',
                              border: '1px solid #bbf7d0',
                              padding: '6px 12px',
                              borderRadius: '6px',
                              fontSize: '12px',
                              fontWeight: '600',
                              cursor: 'pointer',
                            }}
                            onClick={(e) => {
                              e.stopPropagation();
                              router.push('/tasks');
                            }}
                          >
                            My Tasks
                          </button>
                        )}

                        <button
                          type="button"
                          style={{
                            background: '#ffffff',
                            border: '1px solid #cbd5e1',
                            color: '#64748b',
                            padding: '4px 8px',
                            borderRadius: '6px',
                            fontSize: '14px',
                            fontWeight: '700',
                            cursor: 'pointer',
                          }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveMenuMemberId(activeMenuMemberId === member.id ? null : member.id);
                          }}
                        >
                          ⋮
                        </button>

                        {/* Context Menu with Role-Based Options */}
                        {activeMenuMemberId === member.id && (
                          <div
                            style={{
                              position: 'absolute',
                              right: 0,
                              top: '100%',
                              marginTop: '4px',
                              background: '#ffffff',
                              border: '1px solid #e2e8f0',
                              borderRadius: '8px',
                              boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                              width: '200px',
                              zIndex: 100,
                              overflow: 'hidden',
                            }}
                            onClick={(e) => e.stopPropagation()}
                          >
                            {isAdmin && (
                              <button
                                type="button"
                                style={{
                                  width: '100%',
                                  padding: '10px 12px',
                                  textAlign: 'left',
                                  background: 'none',
                                  border: 'none',
                                  borderBottom: '1px solid #f1f5f9',
                                  fontSize: '12px',
                                  fontWeight: '600',
                                  color: '#2563eb',
                                  cursor: 'pointer',
                                }}
                                onClick={() => openAssignModal(member.id)}
                              >
                                ➕ Assign New Task
                              </button>
                            )}

                            <button
                              type="button"
                              style={{
                                width: '100%',
                                padding: '10px 12px',
                                textAlign: 'left',
                                background: 'none',
                                border: 'none',
                                fontSize: '12px',
                                fontWeight: '500',
                                color: '#0f172a',
                                cursor: 'pointer',
                              }}
                              onClick={() => handleSeeMemberTasks(member)}
                            >
                              👁️ View All Tasks
                            </button>

                            {(isAdmin || isSelf) && (
                              <>
                                <button
                                  type="button"
                                  style={{
                                    width: '100%',
                                    padding: '10px 12px',
                                    textAlign: 'left',
                                    background: 'none',
                                    border: 'none',
                                    fontSize: '12px',
                                    fontWeight: '500',
                                    color: '#16a34a',
                                    cursor: 'pointer',
                                  }}
                                  onClick={() => handleMarkAllCompleted(member.id)}
                                >
                                  ✅ Mark All Completed
                                </button>

                                <button
                                  type="button"
                                  style={{
                                    width: '100%',
                                    padding: '10px 12px',
                                    textAlign: 'left',
                                    background: 'none',
                                    border: 'none',
                                    fontSize: '12px',
                                    fontWeight: '500',
                                    color: '#d97706',
                                    cursor: 'pointer',
                                  }}
                                  onClick={() => handleMarkAllPending(member.id)}
                                >
                                  🕒 Mark All Pending
                                </button>
                              </>
                            )}

                            {isAdmin && (
                              <button
                                type="button"
                                style={{
                                  width: '100%',
                                  padding: '10px 12px',
                                  textAlign: 'left',
                                  background: 'none',
                                  border: 'none',
                                  borderTop: '1px solid #f1f5f9',
                                  fontSize: '12px',
                                  fontWeight: '500',
                                  color: '#dc2626',
                                  cursor: 'pointer',
                                }}
                                onClick={() => handleClearMemberTasks(member.id)}
                              >
                                🗑️ Clear All Tasks
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              ) : (
                <div style={{ textAlign: 'center', padding: '24px', color: '#94a3b8' }}>No team members match your search.</div>
              )}
            </div>
          </div>

          {/* Motivation Banner */}
          <div className={styles.quoteCard} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%)', border: '1px solid #bfdbfe' }}>
            <div>
              <div style={{ fontSize: '16px', fontWeight: '700', color: '#1e3a8a', marginBottom: '4px' }}>
                🎯 A strong team builds amazing things!
              </div>
              <div style={{ fontSize: '13px', color: '#1e40af' }}>Support, guide and grow together.</div>
            </div>
            <button
              type="button"
              className={styles.primaryBtn}
              onClick={(e) => {
                e.stopPropagation();
                if (isAdmin) {
                  setShowKeepGoingModal(true);
                } else {
                  router.push('/tasks');
                }
              }}
            >
              Keep Going
            </button>
          </div>
        </div>

        {/* Right Column: Quick Actions & Activities */}
        <div className={styles.rightColumn}>
          <div className={styles.card}>
            <div className={styles.cardHeader}>
              <span className={styles.cardTitle}>Quick Actions</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '8px' }}>
              {isAdmin ? (
                <button
                  type="button"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '10px 12px',
                    borderRadius: '8px',
                    border: '1px solid #e2e8f0',
                    background: '#ffffff',
                    cursor: 'pointer',
                    textAlign: 'left',
                    width: '100%',
                  }}
                  onClick={(e) => {
                    e.stopPropagation();
                    openAssignModal('');
                  }}
                >
                  <div style={{ background: '#eff6ff', color: '#2563eb', padding: '8px', borderRadius: '6px', fontWeight: '700' }}>+</div>
                  <div>
                    <div style={{ fontWeight: '600', fontSize: '13px', color: '#0f172a' }}>Assign New Task</div>
                    <div style={{ fontSize: '11px', color: '#64748b' }}>Create and assign a task to a team member</div>
                  </div>
                </button>
              ) : (
                <Link
                  href="/tasks"
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '10px 12px',
                    borderRadius: '8px',
                    border: '1px solid #e2e8f0',
                    background: '#ffffff',
                    textDecoration: 'none',
                  }}
                >
                  <div style={{ background: '#f0fdf4', color: '#16a34a', padding: '8px', borderRadius: '6px', fontWeight: '700' }}>📋</div>
                  <div>
                    <div style={{ fontWeight: '600', fontSize: '13px', color: '#0f172a' }}>My Tasks</div>
                    <div style={{ fontSize: '11px', color: '#64748b' }}>View and manage your tasks</div>
                  </div>
                </Link>
              )}

              <Link
                href="/tasks"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '10px 12px',
                  borderRadius: '8px',
                  border: '1px solid #e2e8f0',
                  background: '#ffffff',
                  textDecoration: 'none',
                }}
              >
                <div style={{ background: '#f0fdf4', color: '#16a34a', padding: '8px', borderRadius: '6px', fontWeight: '700' }}>📋</div>
                <div>
                  <div style={{ fontWeight: '600', fontSize: '13px', color: '#0f172a' }}>View All Tasks</div>
                  <div style={{ fontSize: '11px', color: '#64748b' }}>See all team tasks and status</div>
                </div>
              </Link>

              <Link
                href="/assigned-tasks"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '10px 12px',
                  borderRadius: '8px',
                  border: '1px solid #e2e8f0',
                  background: '#ffffff',
                  textDecoration: 'none',
                }}
              >
                <div style={{ background: '#fffbeb', color: '#d97706', padding: '8px', borderRadius: '6px', fontWeight: '700' }}>📊</div>
                <div>
                  <div style={{ fontWeight: '600', fontSize: '13px', color: '#0f172a' }}>Team Reports</div>
                  <div style={{ fontSize: '11px', color: '#64748b' }}>View detailed progress report</div>
                </div>
              </Link>
            </div>
          </div>

          {/* Activity Section */}
          <div className={styles.card}>
            <div className={styles.cardHeader}>
              <span className={styles.cardTitle}>Recent Activity</span>
              <button
                type="button"
                className={styles.viewAll}
                style={{ background: 'none', border: 'none', cursor: 'pointer' }}
                onClick={(e) => {
                  e.stopPropagation();
                  setShowAllActivities(true);
                }}
              >
                View All
              </button>
            </div>
            <div className={styles.activityList}>
              {mockActivities.slice(0, 4).map((act) => (
                <div key={act.id} className={styles.activityItem} style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <div className={styles.activityIcon} style={{ background: act.bgColor, color: act.iconColor }}>
                    {act.icon}
                  </div>
                  <div>
                    <div className={styles.activityText}>
                      <b>{act.user}</b> {act.action}
                    </div>
                    <div style={{ fontSize: '11px', color: '#2563eb', fontWeight: '500' }}>{act.detail}</div>
                    <div className={styles.activityTime}>{act.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Modal 1: Edit Team Members / Self Profile Modal */}
      {showEditMembersModal &&
        isLoaded &&
        createPortal(
          <div className={styles.modalOverlay} onClick={() => setShowEditMembersModal(false)}>
            <div className={styles.assignModalContainer} onClick={(e) => e.stopPropagation()} style={{ maxWidth: '480px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                <h2 className={styles.modalHeaderTitle} style={{ margin: 0 }}>
                  {isAdmin ? 'Manage Team Members' : 'Edit My Profile'}
                </h2>
                <button
                  type="button"
                  style={{ border: 'none', background: 'none', cursor: 'pointer', fontSize: '18px' }}
                  onClick={() => setShowEditMembersModal(false)}
                >
                  ✕
                </button>
              </div>

              {isAdmin ? (
                <div>
                  {/* Admin: Add Member Form */}
                  <form onSubmit={handleAddMember} style={{ marginBottom: '20px' }}>
                    <div className={styles.formGroup}>
                      <label className={styles.formLabel}>Add New Member Name *</label>
                      <input
                        type="text"
                        placeholder="Enter full name"
                        className={styles.formInput}
                        value={newMemberName}
                        onChange={(e) => setNewMemberName(e.target.value)}
                        required
                      />
                    </div>
                    <div className={styles.formGroup}>
                      <label className={styles.formLabel}>Role</label>
                      <input
                        type="text"
                        placeholder="e.g. Developer, Designer"
                        className={styles.formInput}
                        value={newMemberRole}
                        onChange={(e) => setNewMemberRole(e.target.value)}
                      />
                    </div>
                    <button type="submit" className={styles.submitBtn} style={{ width: '100%' }}>
                      + Add Member
                    </button>
                  </form>

                  {/* Admin: Existing Members List with Delete option */}
                  <h4 style={{ fontSize: '14px', marginBottom: '10px', color: '#0f172a' }}>Current Members List</h4>
                  <div style={{ maxHeight: '200px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                    {members.map((m) => (
                      <div
                        key={m.id}
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          padding: '8px 12px',
                          border: '1px solid #e2e8f0',
                          borderRadius: '8px',
                          background: '#f8fafc',
                        }}
                      >
                        <div>
                          <div style={{ fontSize: '13px', fontWeight: '600' }}>{m.name}</div>
                          <div style={{ fontSize: '11px', color: '#64748b' }}>{m.role || 'Member'}</div>
                        </div>
                        <button
                          type="button"
                          style={{
                            background: '#fee2e2',
                            color: '#dc2626',
                            border: 'none',
                            padding: '4px 8px',
                            borderRadius: '4px',
                            fontSize: '12px',
                            cursor: 'pointer',
                          }}
                          onClick={() => handleDeleteMember(m.id)}
                        >
                          Delete
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                /* Non-Admin: Rename Self Form */
                <form onSubmit={handleSelfRename}>
                  <div className={styles.formGroup}>
                    <label className={styles.formLabel}>Your Display Name *</label>
                    <input
                      type="text"
                      className={styles.formInput}
                      value={userRenameValue}
                      onChange={(e) => setUserRenameValue(e.target.value)}
                      required
                    />
                  </div>
                  <div className={styles.modalActionRow}>
                    <button
                      type="button"
                      className={styles.cancelBtn}
                      onClick={() => setShowEditMembersModal(false)}
                    >
                      Cancel
                    </button>
                    <button type="submit" className={styles.submitBtn}>
                      Save Changes
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>,
          document.body
        )}

      {/* Admin Assign Task Modal */}
      {showAssignModal &&
        isAdmin &&
        isLoaded &&
        createPortal(
          <div className={styles.modalOverlay} onClick={() => setShowAssignModal(false)}>
            <div className={styles.assignModalContainer} onClick={(e) => e.stopPropagation()}>
              <h2 className={styles.modalHeaderTitle}>Create Task</h2>

              <form onSubmit={handleAssignTask}>
                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Assign To (Team Member) *</label>
                  <select
                    className={styles.formSelect}
                    value={assignedMemberId}
                    onChange={(e) => setAssignedMemberId(e.target.value)}
                    required
                  >
                    <option value="" disabled>Select Team Member</option>
                    {members.map((m) => (
                      <option key={m.id} value={m.id}>
                        👤 {m.name} ({m.role || 'Member'})
                      </option>
                    ))}
                  </select>
                </div>

                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Task Title *</label>
                  <input
                    type="text"
                    placeholder="Enter task title"
                    className={styles.formInput}
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                    required
                  />
                </div>

                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Description</label>
                  <textarea
                    placeholder="Provide details or instructions for this task..."
                    className={styles.formTextarea}
                    rows={3}
                    value={newTaskDescription}
                    onChange={(e) => setNewTaskDescription(e.target.value)}
                  />
                </div>

                <div className={styles.formRowGrid}>
                  <div className={styles.formGroup}>
                    <label className={styles.formLabel}>Priority</label>
                    <select
                      className={styles.formSelect}
                      value={newTaskPriority}
                      onChange={(e) => setNewTaskPriority(e.target.value)}
                    >
                      <option value="⚡ Low">⚡ Low</option>
                      <option value="⚡ Medium">⚡ Medium</option>
                      <option value="⚡ High">⚡ High</option>
                    </select>
                  </div>

                  <div className={styles.formGroup}>
                    <label className={styles.formLabel}>Due Date</label>
                    <input
                      type="date"
                      className={styles.formInput}
                      value={newTaskDueDate}
                      onChange={(e) => setNewTaskDueDate(e.target.value)}
                    />
                  </div>
                </div>

                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Estimated Duration</label>
                  <input
                    type="text"
                    placeholder="e.g. 2 hours or 45 mins"
                    className={styles.formInput}
                    value={estimatedDuration}
                    onChange={(e) => setEstimatedDuration(e.target.value)}
                  />
                </div>

                <div className={styles.formGroup}>
                  <label className={styles.formLabel}>Sub-tasks / Breakdowns</label>
                  <div className={styles.subtaskInputBox}>
                    <input
                      type="text"
                      placeholder="Add step/sub-task..."
                      className={styles.subtaskField}
                      value={newSubtaskTitle}
                      onChange={(e) => setNewSubtaskTitle(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddSubtask();
                        }
                      }}
                    />
                    <button type="button" className={styles.subtaskAddBtn} onClick={handleAddSubtask}>
                      + Add
                    </button>
                  </div>

                  {subtasksInput.length > 0 && (
                    <div className={styles.subtaskListContainer}>
                      {subtasksInput.map((st) => (
                        <div key={st.id} className={styles.subtaskCardItem}>
                          <span className={styles.subtaskText}>{st.title}</span>
                          <button
                            type="button"
                            className={styles.subtaskDeleteBtn}
                            onClick={() => handleRemoveSubtask(st.id)}
                          >
                            ✕
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className={styles.modalActionRow}>
                  <button
                    type="button"
                    className={styles.cancelBtn}
                    onClick={() => setShowAssignModal(false)}
                  >
                    Cancel
                  </button>
                  <button type="submit" className={styles.submitBtn}>
                    Create Task
                  </button>
                </div>
              </form>
            </div>
          </div>,
          document.body
        )}

      {/* Modal 2: See Member Tasks with Scroll View Box */}
      {viewMemberTasks &&
        isLoaded &&
        createPortal(
          <div className={styles.modalOverlay} onClick={() => setViewMemberTasks(null)}>
            <div
              style={{
                background: '#ffffff',
                padding: '24px',
                borderRadius: '16px',
                width: '90%',
                maxWidth: '520px',
                maxHeight: '80vh',
                overflowY: 'auto',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                <h3 style={{ margin: 0, fontSize: '18px', color: '#0f172a' }}>
                  Tasks assigned to {viewMemberTasks.name}
                </h3>
                <button
                  type="button"
                  style={{ border: 'none', background: 'none', cursor: 'pointer', fontSize: '18px' }}
                  onClick={() => setViewMemberTasks(null)}
                >
                  ✕
                </button>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {tasks.filter((t) => t.assignedTo === viewMemberTasks.id).length > 0 ? (
                  tasks
                    .filter((t) => t.assignedTo === viewMemberTasks.id)
                    .map((t) => (
                      <div
                        key={t.id}
                        style={{
                          padding: '12px',
                          borderRadius: '8px',
                          border: '1px solid #e2e8f0',
                          background: '#f8fafc',
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '8px',
                        }}
                      >
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                          <div style={{ fontSize: '14px', fontWeight: '600', color: '#0f172a' }}>{t.title}</div>
                          <span
                            style={{
                              padding: '4px 8px',
                              borderRadius: '12px',
                              fontSize: '11px',
                              fontWeight: '600',
                              textTransform: 'capitalize',
                              background: t.status === 'completed' ? '#dcfce7' : '#fffbeb',
                              color: t.status === 'completed' ? '#15803d' : '#b45309',
                            }}
                          >
                            {t.status}
                          </span>
                        </div>

                        {/* Scroll View Box for Task Details & Description */}
                        {t.description && (
                          <div
                            style={{
                              maxHeight: '120px',
                              overflowY: 'auto',
                              fontSize: '12px',
                              color: '#475569',
                              padding: '8px',
                              background: '#ffffff',
                              border: '1px solid #e2e8f0',
                              borderRadius: '6px',
                              whiteSpace: 'pre-wrap',
                            }}
                          >
                            {t.description}
                          </div>
                        )}

                        <div style={{ fontSize: '11px', color: '#64748b' }}>
                          Due: {t.dueDate || 'Jun 20, 2026'} • Priority: <b>{t.priority || 'Medium'}</b>
                        </div>
                      </div>
                    ))
                ) : (
                  <div style={{ textAlign: 'center', color: '#94a3b8', padding: '16px' }}>
                    No active tasks assigned to this member.
                  </div>
                )}
              </div>
            </div>
          </div>,
          document.body
        )}

      {/* Modal 3: Keep Going Admin Modal */}
      {showKeepGoingModal &&
        isLoaded &&
        createPortal(
          <div className={styles.modalOverlay} onClick={() => setShowKeepGoingModal(false)}>
            <div
              style={{
                background: '#ffffff',
                padding: '24px',
                borderRadius: '16px',
                width: '90%',
                maxWidth: '400px',
                textAlign: 'center',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <h3 style={{ margin: '0 0 8px 0', fontSize: '18px', color: '#0f172a' }}>Admin Navigation</h3>
              <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '20px' }}>
                Where would you like to navigate next?
              </p>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <button
                  type="button"
                  style={{
                    padding: '12px',
                    borderRadius: '8px',
                    border: '1px solid #cbd5e1',
                    background: '#eff6ff',
                    color: '#2563eb',
                    fontWeight: '600',
                    cursor: 'pointer',
                  }}
                  onClick={() => {
                    setShowKeepGoingModal(false);
                    router.push('/tasks');
                  }}
                >
                  Go to My Tasks
                </button>

                <button
                  type="button"
                  style={{
                    padding: '12px',
                    borderRadius: '8px',
                    border: 'none',
                    background: '#2563eb',
                    color: '#ffffff',
                    fontWeight: '600',
                    cursor: 'pointer',
                  }}
                  onClick={() => {
                    setShowKeepGoingModal(false);
                    router.push('/assigned-tasks');
                  }}
                >
                  Go to Assigned Tasks
                </button>
              </div>
            </div>
          </div>,
          document.body
        )}

      {/* Modal 4: All Activities Modal */}
      {showAllActivities &&
        isLoaded &&
        createPortal(
          <div className={styles.modalOverlay} onClick={() => setShowAllActivities(false)}>
            <div
              style={{
                background: '#ffffff',
                padding: '24px',
                borderRadius: '16px',
                width: '90%',
                maxWidth: '550px',
                maxHeight: '80vh',
                overflowY: 'auto',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                <h3 style={{ margin: 0, fontSize: '18px' }}>All Team Activities</h3>
                <button
                  type="button"
                  style={{ border: 'none', background: 'none', cursor: 'pointer', fontSize: '18px' }}
                  onClick={() => setShowAllActivities(false)}
                >
                  ✕
                </button>
              </div>

              <div style={{ display: 'flex', gap: '8px', marginBottom: '16px', flexWrap: 'wrap' }}>
                {['All', 'Assigned', 'Completed', 'Added'].map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    style={{
                      padding: '6px 12px',
                      borderRadius: '16px',
                      border: '1px solid #cbd5e1',
                      background: activityFilter === cat ? '#2563eb' : '#fff',
                      color: activityFilter === cat ? '#fff' : '#000',
                      fontSize: '12px',
                      cursor: 'pointer',
                    }}
                    onClick={() => setActivityFilter(cat)}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {mockActivities
                  .filter((a) => activityFilter === 'All' || a.category === activityFilter)
                  .map((act) => (
                    <div
                      key={act.id}
                      style={{
                        padding: '12px',
                        border: '1px solid #e2e8f0',
                        borderRadius: '8px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px',
                        background: '#f8fafc',
                      }}
                    >
                      <div
                        style={{
                          width: '32px',
                          height: '32px',
                          borderRadius: '6px',
                          background: act.bgColor,
                          color: act.iconColor,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        {act.icon}
                      </div>
                      <div>
                        <div style={{ fontSize: '13px' }}>
                          <b>{act.user}</b> {act.action}
                        </div>
                        <div style={{ fontSize: '12px', color: '#2563eb', fontWeight: '600' }}>{act.detail}</div>
                        <div style={{ fontSize: '11px', color: '#64748b' }}>{act.time}</div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>,
          document.body
        )}
    </div>
  );
}
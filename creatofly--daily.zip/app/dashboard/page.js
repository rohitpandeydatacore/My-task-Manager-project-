'use client';

import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { initialTasks } from '../data/tasks';
import { teamMembers as defaultMembers } from '../data/users';
import { getStoredTasks, getStoredUsers } from '../utils/storage';
import styles from './dashboard.module.css';

// Sample Recent Activities dataset with categories
const mockActivities = [
  {
    id: 1,
    taskId: 1,
    user: 'Rahul Kumar',
    action: 'completed task "Build Dashboard UI"',
    statusCategory: 'Completed',
    time: '10 mins ago',
    icon: '✅',
    bgColor: '#dcfce7',
    iconColor: '#15803d',
  },
  {
    id: 2,
    taskId: 2,
    user: 'Brijesh Singh',
    action: 'assigned task "Create Task Card Component" to Rahul',
    statusCategory: 'Assigned',
    time: '1 hour ago',
    icon: '📌',
    bgColor: '#f3e8ff',
    iconColor: '#7e22ce',
  },
  {
    id: 3,
    taskId: 3,
    user: 'Priya Sharma',
    action: 'started working on "Practice CSS Flexbox"',
    statusCategory: 'In Progress',
    time: '2 hours ago',
    icon: '⏳',
    bgColor: '#fef3c7',
    iconColor: '#b45309',
  },
  {
    id: 4,
    taskId: 4,
    user: 'Amit Patel',
    action: 'added new task "Read Next.js Documentation"',
    statusCategory: 'Added',
    time: '4 hours ago',
    icon: '➕',
    bgColor: '#e0f2fe',
    iconColor: '#0369a1',
  },
  {
    id: 5,
    taskId: 5,
    user: 'Rahul Kumar',
    action: 'completed task "Fix Responsive Layout Issue"',
    statusCategory: 'Completed',
    time: 'Yesterday',
    icon: '✅',
    bgColor: '#dcfce7',
    iconColor: '#15803d',
  },
];

export default function DashboardPage() {
  const [tasks, setTasks] = useState(initialTasks);
  const [teamMembers, setTeamMembers] = useState(defaultMembers);
  const [currentUser, setCurrentUser] = useState(defaultMembers[0]);
  const [mounted, setMounted] = useState(false);

  // Modal and Activity States
  const [showAllActivities, setShowAllActivities] = useState(false);
  const [activityFilter, setActivityFilter] = useState('All');
  const [inspectTask, setInspectTask] = useState(null);

  useEffect(() => {
    setMounted(true);
    setTasks(getStoredTasks(initialTasks));
    setTeamMembers(getStoredUsers(defaultMembers));

    const savedUser = localStorage.getItem('creatofly_active_user');
    if (savedUser) {
      try {
        setCurrentUser(JSON.parse(savedUser));
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  // Filter activities inside View All modal
  const filteredActivities = mockActivities.filter((act) => {
    if (activityFilter === 'All') return true;
    return act.statusCategory.toLowerCase() === activityFilter.toLowerCase();
  });




  // Handler for "See Task" button
  function handleSeeTask(taskId, e) {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    const found = tasks.find((t) => t.id === taskId) || {
      id: taskId,
      title: `Task #${taskId} Activity Detail`,
      description: 'Activity details for task execution in workspace.',
      status: 'in-progress',
      dueDate: 'Jun 18, 2026',
      assignedBy: 1,
      assignedTo: 2,
    };
    setInspectTask(found);
  }

  return (
    <div className={styles.container}>
      {/* Recent Activity Card */}
      <div className={styles.card}>
        <div className={styles.cardHeader}>
          <span className={styles.cardTitle}>Recent Activity</span>
          <button
            type="button"
            className={styles.viewAllLink}
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              setShowAllActivities(true);
            }}
          >
            View All
          </button>
        </div>

        <div className={styles.activityList}>
          {mockActivities.slice(0, 4).map((act) => (
            <div key={act.id} className={styles.activityCardItem}>
              <div className={styles.activityLeft}>
                <div
                  className={styles.activityIcon}
                  style={{ background: act.bgColor, color: act.iconColor }}
                >
                  {act.icon}
                </div>
                <div className={styles.activityDetails}>
                  <div className={styles.activityText}>
                    <b>{act.user}</b> {act.action}
                  </div>
                  <div className={styles.activityMeta}>
                    <span>🕒 {act.time}</span>
                  </div>
                </div>
              </div>

              <div className={styles.activityRight}>
                <span
                  className={`${styles.statusTag} ${
                    act.statusCategory === 'Completed'
                      ? styles.tagCompleted
                      : act.statusCategory === 'In Progress'
                      ? styles.tagInProgress
                      : act.statusCategory === 'Added'
                      ? styles.tagAdded
                      : styles.tagAssigned
                  }`}
                >
                  {act.statusCategory}
                </span>

                <button
                  type="button"
                  className={styles.seeBtn}
                  onClick={(e) => handleSeeTask(act.taskId, e)}
                >
                  See Task
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal 1: All Activities Modal ("View All" click via Portal) */}
      {showAllActivities &&
        mounted &&
        createPortal(
          <div
            className={styles.modalOverlay}
            onClick={() => setShowAllActivities(false)}
          >
            <div
              className={styles.modalContent}
              onClick={(e) => e.stopPropagation()}
            >
              <div className={styles.modalHeader}>
                <span className={styles.modalTitle}>
                  All Recent Workspace Activities
                </span>
                <button
                  type="button"
                  className={styles.closeBtn}
                  onClick={() => setShowAllActivities(false)}
                >
                  ✕
                </button>
              </div>

              {/* Status Category Filter Pills */}
              <div className={styles.filterPills}>
                {['All', 'Added', 'Completed', 'In Progress', 'Assigned'].map(
                  (cat) => (
                    <button
                      key={cat}
                      type="button"
                      className={`${styles.pillBtn} ${
                        activityFilter === cat ? styles.activePill : ''
                      }`}
                      onClick={() => setActivityFilter(cat)}
                    >
                      {cat}
                    </button>
                  )
                )}
              </div>

              <div className={styles.modalBodyScroll}>
                {filteredActivities.length > 0 ? (
                  filteredActivities.map((act) => (
                    <div key={act.id} className={styles.activityCardItem}>
                      <div className={styles.activityLeft}>
                        <div
                          className={styles.activityIcon}
                          style={{
                            background: act.bgColor,
                            color: act.iconColor,
                          }}
                        >
                          {act.icon}
                        </div>
                        <div className={styles.activityDetails}>
                          <div className={styles.activityText}>
                            <b>{act.user}</b> {act.action}
                          </div>
                          <div className={styles.activityMeta}>
                            <span>🕒 {act.time}</span>
                          </div>
                        </div>
                      </div>

                      <div className={styles.activityRight}>
                        <span
                          className={`${styles.statusTag} ${
                            act.statusCategory === 'Completed'
                              ? styles.tagCompleted
                              : act.statusCategory === 'In Progress'
                              ? styles.tagInProgress
                              : act.statusCategory === 'Added'
                              ? styles.tagAdded
                              : styles.tagAssigned
                          }`}
                        >
                          {act.statusCategory}
                        </span>

                        <button
                          type="button"
                          className={styles.seeBtn}
                          onClick={(e) => handleSeeTask(act.taskId, e)}
                        >
                          See Task
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div
                    style={{
                      textAlign: 'center',
                      padding: '20px',
                      color: '#64748b',
                    }}
                  >
                    No activities found for this category.
                  </div>
                )}
              </div>

              <div className={styles.modalFooter}>
                <button
                  type="button"
                  className={styles.seeBtn}
                  onClick={() => setShowAllActivities(false)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>,
          document.body
        )}

      {/* Modal 2: Task Detail Inspection Popup ("See Task" click via Portal) */}
      {inspectTask &&
        mounted &&
        createPortal(
          <div
            className={styles.modalOverlay}
            style={{ zIndex: 100000 }}
            onClick={() => setInspectTask(null)}
          >
            <div
              className={styles.modalContent}
              onClick={(e) => e.stopPropagation()}
            >
              <div className={styles.modalHeader}>
                <span className={styles.modalTitle}>Task Details</span>
                <button
                  type="button"
                  className={styles.closeBtn}
                  onClick={() => setInspectTask(null)}
                >
                  ✕
                </button>
              </div>

              <div className={styles.modalField}>
                <span className={styles.modalLabel}>Task Title</span>
                <span
                  className={styles.modalVal}
                  style={{ fontWeight: '700', fontSize: '15px' }}
                >
                  {inspectTask.title}
                </span>
              </div>

              <div className={styles.modalField}>
                <span className={styles.modalLabel}>Description</span>
                <span className={styles.modalVal}>
                  {inspectTask.description ||
                    'Details regarding this activity log.'}
                </span>
              </div>

              <div className={styles.modalGrid}>
                <div className={styles.modalField}>
                  <span className={styles.modalLabel}>Due Date</span>
                  <span className={styles.modalVal}>
                    {inspectTask.dueDate || 'Jun 18, 2026'}
                  </span>
                </div>
                <div className={styles.modalField}>
                  <span className={styles.modalLabel}>Status</span>
                  <span
                    className={styles.modalVal}
                    style={{ textTransform: 'capitalize', fontWeight: '600' }}
                  >
                    {inspectTask.status}
                  </span>
                </div>
              </div>

              <div className={styles.modalFooter}>
                <button
                  type="button"
                  className={styles.seeBtn}
                  onClick={() => setInspectTask(null)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>,
          document.body
        )}
    </div>
  );
}